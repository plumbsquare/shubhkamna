@echo off
REM ══════════════════════════════════════════════════════════════
REM  शुभकामना — ONE-COMMAND SETUP (Windows)
REM
REM  USAGE:
REM    setup.bat
REM    setup.bat my-wish-site
REM    setup.bat my-wish-site shubhkamna.in
REM
REM  ज़रूरी: Git for Windows + GitHub CLI (gh) installed
REM    https://git-scm.com/downloads   |   https://cli.github.com
REM ══════════════════════════════════════════════════════════════
setlocal
chcp 65001 >nul

set REPO_NAME=%1
if "%REPO_NAME%"=="" set REPO_NAME=shubhkamna
set DOMAIN=%2
set VISIBILITY=public

echo.
echo ==============================================
echo  🪔  Shubhkamna - GitHub Pages setup
echo ==============================================
echo  Folder : %CD%
echo  Repo   : %REPO_NAME%
echo  Domain : %DOMAIN%
echo.

where git >nul 2>nul
if errorlevel 1 (
  echo [X] git install karo: https://git-scm.com/downloads
  pause & exit /b 1
)
where gh >nul 2>nul
if errorlevel 1 (
  echo [X] GitHub CLI (gh) install karo: https://cli.github.com
  pause & exit /b 1
)
gh auth status >nul 2>nul
if errorlevel 1 (
  echo [!] gh login kar rahe hain...
  gh auth login
)

REM ---------- 1. _github -> .github ----------
if exist "_github" if not exist ".github" (
  move "_github" ".github" >nul
  echo [OK] _github -> .github rename ho gaya
)
if not exist ".github\workflows\pages.yml" (
  echo [X] .github\workflows\pages.yml nahi mila - zip sahi extract hui hai kya?
  pause & exit /b 1
)

REM ---------- 2. git init + commit ----------
git init -q
git add -A
git diff --cached --quiet
if errorlevel 1 (
  git -c user.name="Shubhkamna Setup" -c user.email="setup@shubhkamna.local" commit -q -m "🚀 Shubhkamna v2 - animated greeting links"
  echo [OK] commit ho gaya
) else (
  echo . koi naya change nahi
)

REM ---------- 3. repo + push ----------
gh repo view %REPO_NAME% >nul 2>nul
if errorlevel 1 (
  gh repo create %REPO_NAME% --%VISIBILITY% --source=. --remote=origin --push
  echo [OK] Repo bana + push ho gaya
) else (
  echo [i] Repo pehle se hai - push kar rahe hain
  git remote get-url origin >nul 2>nul
  if errorlevel 1 gh repo set-default %REPO_NAME% >nul
  git push -u origin HEAD
)

for /f "delims=" %%O in ('gh repo view %REPO_NAME% --json owner -q .owner.login') do set OWNER=%%O
for /f "delims=" %%B in ('git rev-parse --abbrev-ref HEAD') do set BRANCH=%%B

REM ---------- 4. Pages enable ----------
gh api --method POST "repos/%OWNER%/%REPO_NAME%/pages" -f source[branch]=%BRANCH% -f source[path]=/ >nul 2>nul
if errorlevel 1 gh api --method POST "repos/%OWNER%/%REPO_NAME%/pages" -F build_type=workflow >nul 2>nul

REM ---------- 5. Custom domain ----------
if not "%DOMAIN%"=="" (
  echo %DOMAIN%> CNAME
  git add CNAME
  git -c user.name="Shubhkamna Setup" -c user.email="setup@shubhkamna.local" commit -q -m "custom domain: %DOMAIN%"
  git push -q origin HEAD
  gh secret set CUSTOM_DOMAIN --body "%DOMAIN%" --repo "%OWNER%/%REPO_NAME%"
  echo [OK] CNAME + CUSTOM_DOMAIN secret set
  echo.
  echo [!] DNS me ye records daalo:
  echo     CNAME  www  -^>  %OWNER%.github.io
  echo     A      @    -^>  185.199.108.153
  echo     A      @    -^>  185.199.109.153
  echo     A      @    -^>  185.199.110.153
  echo     A      @    -^>  185.199.111.153
)

echo.
echo ==============================================
echo  [OK] Sab set ho gaya!
echo ==============================================
echo.
echo  Site     : https://%OWNER%.github.io/%REPO_NAME%/
if not "%DOMAIN%"=="" echo  Site     : https://%DOMAIN%/
echo  Repo     : https://github.com/%OWNER%/%REPO_NAME%
echo  Actions  : https://github.com/%OWNER%/%REPO_NAME%/actions
echo  Settings : https://github.com/%OWNER%/%REPO_NAME%/settings/pages
echo.
echo  Pehla deploy 1-2 minute me ho jayega.
echo.
pause
