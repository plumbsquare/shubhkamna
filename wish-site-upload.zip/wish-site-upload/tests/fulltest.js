/* ============================================================
   FULL TEST SUITE  —  wish-site
   A. Build / static checks   B. Landing page (index.html)
   C. Recipient page (wish.html)   D. 404 page   E. Content/SEO
   Exit code 0 = सब green
   ============================================================ */
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const { JSDOM, VirtualConsole } = require('jsdom');

const ROOT = process.env.ROOT_OVERRIDE || require('path').resolve(__dirname, '..');
const errors = [];
let pass = 0, fail = 0;
const results = [];

function ok(name, cond, extra) {
  if (cond) { pass++; results.push(['✅', name, extra || '']); }
  else { fail++; results.push(['❌', name, extra || '']); }
}
function section(t) { results.push(['──', t, '']); }

function stubCanvas(win) {
  win.HTMLCanvasElement.prototype.getContext = function () {
    return {
      setTransform(){}, clearRect(){}, save(){}, restore(){}, translate(){}, rotate(){},
      beginPath(){}, arc(){}, fill(){}, fillRect(){}, stroke(){}, moveTo(){}, lineTo(){},
      closePath(){}, quadraticCurveTo(){}, bezierCurveTo(){}, ellipse(){},
      createLinearGradient(){ return { addColorStop(){} }; },
      createRadialGradient(){ return { addColorStop(){} }; },
      measureText(){ return { width: 10 }; }, fillText(){}, strokeText(){}
    };
  };
  win.requestAnimationFrame = (cb) => setTimeout(() => cb(Date.now()), 16);
  win.cancelAnimationFrame = (id) => clearTimeout(id);
  win.scrollTo = function () {};
  if (!win.navigator.clipboard) {
    try { Object.defineProperty(win.navigator, 'clipboard', { value: { writeText: () => Promise.resolve() }, configurable: true }); }
    catch (e) {}
  }
}

function loadPage(file, hash, label, scripts, runScripts) {
  const html = fs.readFileSync(path.join(ROOT, file), 'utf8');
  const vc = new VirtualConsole();
  vc.on('jsdomError', (e) => errors.push(`[${label}] jsdomError: ${e.message}`));
  vc.on('error', (...a) => errors.push(`[${label}] console.error: ${a.join(' ')}`));
  const dom = new JSDOM(html, {
    url: 'https://example.github.io/repo/' + file + (hash || ''),
    runScripts: runScripts || 'outside-only', pretendToBeVisual: true, virtualConsole: vc
  });
  const win = dom.window;
  stubCanvas(win);
  for (const js of scripts) {
    try { win.eval(fs.readFileSync(path.join(ROOT, 'assets/js', js), 'utf8')); }
    catch (e) { errors.push(`[${label}] ${js}: ${e.message}`); }
  }
  return { dom, win, d: win.document };
}
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const R = (p) => path.join(ROOT, p);

(async () => {

/* ==================== A. BUILD / STATIC ==================== */
section('A. Build & static checks');
const need = ['index.html','wish.html','404.html','robots.txt','sitemap.xml','README.md','CNAME.example',
  'assets/css/base.css','assets/css/wish.css','assets/js/festivals.js',
  'assets/js/app.js','assets/js/wish.js','assets/js/fx.js','assets/js/audio.js','assets/img/og.jpg',
  'assets/img/favicon.svg'];
const missing = need.filter(f => !fs.existsSync(R(f)));
ok('सारी ज़रूरी files मौजूद', missing.length === 0, missing.join(', '));

for (const js of ['festivals.js','app.js','wish.js','fx.js','audio.js']) {
  let clean = true;
  try { execSync(`node --check "${R('assets/js/' + js)}"`); } catch (e) { clean = false; }
  ok(`JS syntax: ${js}`, clean);
}

for (const f of ['index.html','wish.html','404.html']) {
  const raw = fs.readFileSync(R(f), 'utf8');
  // attribute values + comments हटाकर tag structure देखो
  const html = raw.replace(/<!--[\s\S]*?-->/g, '').replace(/<script[\s\S]*?<\/script>/gi, '').replace(/="[^"]*"/g, '=""');
  const VOID = ['area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr','svg','path','circle','line','g'];
  const stack = []; let bad = '';
  const re = /<(\/?)([a-zA-Z0-9]+)([^>]*?)(\/?)>/g; let m;
  while ((m = re.exec(html))) {
    const closing = m[1] === '/', tag = m[2].toLowerCase(), self = m[4] === '/';
    if (VOID.includes(tag) || self) continue;
    if (!closing) stack.push(tag);
    else { const t = stack.pop(); if (t !== tag) { bad = `</${tag}> != <${t}>`; break; } }
  }
  ok(`HTML balanced: ${f}`, !bad && stack.length === 0, bad || (stack.length ? 'unclosed ' + stack : ''));
}

// हर HTML में जो local asset reference है वो file exist करे
let refBad = [];
for (const f of ['index.html','wish.html','404.html']) {
  const html = fs.readFileSync(R(f), 'utf8');
  const refs = [...html.matchAll(/(?:href|src)="([^"]+)"/g)].map(x => x[1]);
  refs.forEach(u => {
    if (/^(https?:|data:|mailto:|#|\/)/.test(u)) return;
    const clean = u.split('#')[0].split('?')[0];
    if (!clean) return;
    if (!fs.existsSync(R(clean))) refBad.push(`${f} → ${u}`);
  });
}
ok('सारे local asset references मौजूद', refBad.length === 0, refBad.join(', '));

const allHtml = ['index.html','wish.html'].map(f => fs.readFileSync(R(f), 'utf8')).join('\n')
  .replace(/<!--[\s\S]*?-->/g, '');   // commented-out ad placeholders हटाओ
ok('कोई third-party JS library नहीं (CDN नहीं)',
  !/cdnjs|jsdelivr|unpkg|cdn\.jsdelivr/i.test(allHtml) && !/<script[^>]+src="http/i.test(allHtml),
  'सिर्फ़ Google Fonts (CSS) allowed है');

const wfPath = ['.github/workflows/pages.yml','_github/workflows/pages.yml'].find(f=>fs.existsSync(R(f)));
  const wf = wfPath ? fs.readFileSync(R(wfPath),'utf8') : '';
  ok('Workflow file मौजूद', !!wfPath, wfPath || 'missing');
  ok('Workflow: deploy + artifact + branches + prepare step', /actions\/deploy-pages@/.test(wf) && /actions\/upload-pages-artifact@/.test(wf) && /branches:/.test(wf) && /prepare_site/.test(wf));

const robots = fs.readFileSync(R('robots.txt'), 'utf8');
ok('robots.txt में Sitemap है', /Sitemap:\s*https?:\/\//.test(robots));
const sm = fs.readFileSync(R('sitemap.xml'), 'utf8');
ok('sitemap.xml valid structure', /<urlset/.test(sm) && /<loc>https:\/\//.test(sm));

const sizes = {
  'index.html': ['index.html','assets/css/base.css','assets/js/festivals.js','assets/js/app.js'],
  'wish.html':  ['wish.html','assets/css/wish.css','assets/js/festivals.js','assets/js/wish.js','assets/js/fx.js','assets/js/audio.js']
};
for (const k in sizes) {
  const total = sizes[k].reduce((s, f) => s + fs.statSync(R(f)).size, 0);
  ok(`पेज वज़न ${k} < 120KB (4G के लिए)`, total < 120 * 1024, (total / 1024).toFixed(1) + ' KB');
}

/* ==================== B. LANDING PAGE ==================== */
section('B. Landing page (index.html)');
{
  const { win, d } = loadPage('index.html', '', 'index', ['festivals.js', 'app.js']);
  await sleep(600);

  const cards = d.querySelectorAll('#festGrid .fest');
  ok('11 त्योहार कार्ड रेंडर हुए', cards.length === 11, cards.length + ' कार्ड');
  ok('पहला कार्ड active है', !!d.querySelector('#festGrid .fest.active'));

  // nav anchors
  const navIds = [...d.querySelectorAll('.nav a')].map(a => (a.getAttribute('href') || '').replace('#', ''));
  const badNav = navIds.filter(id => id && !d.getElementById(id));
  ok('सारे nav anchor तैयार हैं', badNav.length === 0, badNav.join(', '));

  // festival click → theme + preview
  const holi = d.querySelector('[data-key="holi"]');
  holi.dispatchEvent(new win.MouseEvent('click', { bubbles: true }));
  await sleep(500);
  ok('त्योहार click → theme बदला', win.document.documentElement.style.getPropertyValue('--gold').trim() === '#ffe66d',
     win.document.documentElement.style.getPropertyValue('--gold'));
  ok('त्योहार click → preview hint बदला', /होली/.test(d.getElementById('previewHint').textContent));
  ok('त्योहार click → iframe src बदला', /f=holi/.test(d.getElementById('frame').getAttribute('src')));

  // counters
  const name = d.getElementById('inName');
  name.value = 'राहुल';
  name.dispatchEvent(new win.Event('input', { bubbles: true }));
  ok('नाम counter चल रहा है', d.getElementById('cntName').textContent === '5/40', d.getElementById('cntName').textContent);
  const msg = d.getElementById('inMsg');
  msg.value = 'दीयों की रोशनी';
  msg.dispatchEvent(new win.Event('input', { bubbles: true }));
  ok('मैसेज counter चल रहा है', d.getElementById('cntMsg').textContent === msg.value.length + '/220', d.getElementById('cntMsg').textContent);

  // empty name guard
  name.value = '   ';
  name.dispatchEvent(new win.Event('input', { bubbles: true }));
  d.getElementById('makeBtn').dispatchEvent(new win.MouseEvent('click', { bubbles: true }));
  await sleep(120);
  ok('खाली नाम पर लिंक नहीं बना', d.getElementById('result').style.display !== 'block');
  ok('खाली नाम पर toast दिखा', /नाम/.test(d.getElementById('toast').textContent), d.getElementById('toast').textContent);

  // generate
  const TEST_NAME = 'प्रिया';
  name.value = TEST_NAME;
  msg.value = 'होली के रंग आपकी ज़िंदगी में छा जाएँ';
  d.getElementById('inFrom').value = 'स्नेहा';
  name.dispatchEvent(new win.Event('input', { bubbles: true }));
  d.getElementById('makeBtn').dispatchEvent(new win.MouseEvent('click', { bubbles: true }));
  await sleep(200);
  const link = d.getElementById('outLink').value;
  const dec = decodeURIComponent(link);
  ok('लिंक बन गया (सही path + नाम)', /\/repo\/wish\.html#f=holi/.test(link) && dec.includes('n=' + TEST_NAME.normalize('NFC')), dec.slice(0, 78) + '…');
  ok('Result panel दिखा', d.getElementById('result').style.display === 'block');
  ok('WhatsApp share link सही', /wa\.me\/\?text=/.test(d.getElementById('waShare').href) &&
     decodeURIComponent(d.getElementById('waShare').href).includes(TEST_NAME.normalize('NFC')));
  ok('"खोलकर देखो" = generated link', d.getElementById('openBtn2').href === link);

  // history
  ok('History में 1 entry', d.querySelectorAll('#histList .hist-item').length === 1);
  d.getElementById('clearHist').dispatchEvent(new win.MouseEvent('click', { bubbles: true }));
  await sleep(100);
  ok('History clear हुई', d.querySelectorAll('#histList .hist-item').length === 0);

  // footer year
  ok('Footer में साल डाला', /^\d{4}$/.test(d.getElementById('yr').textContent), d.getElementById('yr').textContent);

  // back to top
  const toTop = d.getElementById('toTop');
  ok('Back-to-top button मौजूद', !!toTop);
  Object.defineProperty(win, 'scrollY', { value: 600, configurable: true });
  win.dispatchEvent(new win.Event('scroll'));
  await sleep(60);
  ok('Scroll पर back-to-top दिखा', toTop.classList.contains('show'));
}
{
  // hash prefill
  const { win, d } = loadPage('index.html', '#f=holi&n=Priya&m=Hello&b=Rohit', 'index-hash', ['festivals.js', 'app.js']);
  await sleep(400);
  ok('Hash से नाम prefill हुआ', d.getElementById('inName').value === 'Priya', d.getElementById('inName').value);
  ok('Hash से मैसेज prefill हुआ', d.getElementById('inMsg').value === 'Hello');
  ok('Hash से "from" prefill हुआ', d.getElementById('inFrom').value === 'Rohit');
  ok('Hash से त्योहार select हुआ', /होली/.test(d.getElementById('previewHint').textContent));
}

/* ==================== C. RECIPIENT PAGE ==================== */
section('C. Recipient page (wish.html)');
{
  const { win, d } = loadPage('wish.html',
    '#f=diwali&n=' + encodeURIComponent('राहुल') + '&m=' + encodeURIComponent('शुभ दीपावली 🎉') + '&b=' + encodeURIComponent('अमित'),
    'wish', ['festivals.js', 'fx.js', 'audio.js', 'wish.js']);
  await sleep(300);

  ok('शीर्षक सही', d.getElementById('fTitle').textContent === 'शुभ दीपावली', d.getElementById('fTitle').textContent);
  ok('नाम सही दिखा', d.getElementById('fName').textContent === 'राहुल', d.getElementById('fName').textContent);
  ok('नाम पर sheen effect है', !!d.querySelector('#fName .sheen'));
  ok('"from" line सही', /अमित/.test(d.getElementById('fFrom').textContent));
  ok('Scene बना (दीये/तारे/रंगोली)', d.querySelectorAll('.diya').length > 0 && d.querySelectorAll('.star').length > 0 && d.querySelectorAll('.rangoli').length > 0);
  ok('WhatsApp share text में नाम', /राहुल/.test(decodeURIComponent(d.getElementById('waBtn').getAttribute('href'))));
  ok('"ये भी भेजो" सही festival के साथ', d.getElementById('againBtn').getAttribute('href') === 'index.html#f=diwali', d.getElementById('againBtn').getAttribute('href'));
  ok('Tab title में नाम', /^राहुल /.test(d.title), d.title);
  ok('"for you" ribbon मौजूद', !!d.querySelector('.for-you'));

  // typewriter पूरा हुआ?
  await sleep(3400);
  const typed = d.getElementById('fMsg').textContent;
  ok('मैसेज पूरा टाइप हुआ (emoji सहित)', typed === 'शुभ दीपावली 🎉', JSON.stringify(typed));
  ok('Curtain अपने आप खुला', d.getElementById('curtain').classList.contains('open'));
  ok('नाम reveal animation लगा', d.getElementById('fName').classList.contains('reveal'));
}
{
  // curtain tap → instant open
  const { win, d } = loadPage('wish.html', '#f=holi&n=Test', 'wish-tap', ['festivals.js', 'fx.js', 'audio.js', 'wish.js']);
  await sleep(200);
  const curtain = d.getElementById('curtain');
  curtain.dispatchEvent(new win.MouseEvent('click', { bubbles: true }));
  await sleep(100);
  ok('Curtain पर tap → तुरंत खुला', curtain.classList.contains('open'));
}
{
  // interaction: stage click → celebration, music toggle
  const { win, d } = loadPage('wish.html', '#f=birthday&n=Test', 'wish-inter', ['festivals.js', 'fx.js', 'audio.js', 'wish.js']);
  await sleep(2200);
  const stage = d.getElementById('stage');
  stage.dispatchEvent(new win.MouseEvent('click', { bubbles: true, clientX: 100, clientY: 100 }));
  ok('Screen पर tap → hint छिपा', d.querySelector('.hint-tap').style.display === 'none');
  d.getElementById('celebrateBtn').dispatchEvent(new win.MouseEvent('click', { bubbles: true }));
  ok('"उत्सव मनाओ" बटन काम करता है', true);
  const mb = d.getElementById('musicBtn');
  mb.dispatchEvent(new win.MouseEvent('click', { bubbles: true }));
  await sleep(60);
  ok('Music toggle aria-label बदलता है', /बंद करें|चालू करें/.test(mb.getAttribute('aria-label')), mb.getAttribute('aria-label'));
}
{
  // XSS / special chars safety
  const { win, d } = loadPage('wish.html',
    '#f=diwali&n=%3Cscript%3Ealert(1)%3C%2Fscript%3E%26%20%22quotes%22&m=%3Cimg%20src%3Dx%20onerror%3Dalert(1)%3E',
    'wish-xss', ['festivals.js', 'fx.js', 'audio.js', 'wish.js']);
  await sleep(3400);
  ok('Script tag name में inject नहीं हुआ', d.querySelectorAll('#fName script').length === 0);
  ok('नाम सही text रहा', d.getElementById('fName').textContent.includes('<script>'));
  ok('Img onerror inject नहीं हुआ', d.querySelectorAll('#fMsg img').length === 0);
}
{
  // हर त्योहार error-free
  const keys = ['diwali','dhanteras','bhai_dooj','rakhi','holi','eid','newyear','goodmorning','valentine','birthday','thanks'];
  let bad = [];
  for (const k of keys) {
    const before = errors.length;
    const { d } = loadPage('wish.html', '#f=' + k + '&n=Test', 'fest-' + k, ['festivals.js', 'fx.js', 'audio.js', 'wish.js']);
    await sleep(60);
    if (errors.length > before) bad.push(k);
    if (!d.getElementById('fTitle').textContent) bad.push(k + '(title)');
  }
  ok('11 त्योहार — सब error-free', bad.length === 0, bad.join(', '));
}

/* ==================== D. 404 PAGE ==================== */
section('D. 404 page');
{
  const { d } = loadPage('404.html', '', '404', [], 'dangerously');
  await sleep(200);
  ok('404 में दोनों relative link', d.querySelectorAll('a.btn').length === 2 &&
     [...d.querySelectorAll('a.btn')].every(a => a.getAttribute('href').startsWith('./')));
  ok('404 में festive sparkles बन रहे हैं', d.querySelectorAll('.dot').length > 10);
}

/* ==================== E. CONTENT / SEO ==================== */
section('E. Content, SEO & monetization');
{
  const idx = fs.readFileSync(R('index.html'), 'utf8');
  ok('Open Graph image absolute URL है', /og:image" content="https:\/\/[^"]+og\.jpg"/.test(idx));
  ok('Canonical tag है', /rel="canonical"/.test(idx));
  ok('JSON-LD structured data valid JSON', (() => {
    try { const m = idx.match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/); JSON.parse(m[1]); return true; }
    catch (e) { return false; }
  })());
  ok('FAQ + न्यू फ़ोर + B2B सेक्शन मौजूद', ['id="faq"','id="business"','id="how"','id="preview"','id="make"'].every(id => idx.includes(id)));
  ok('AdSense slot comment मौजूद', idx.includes('adsbygoogle'));
  ok('Adsterra slot comment मौजूद', idx.toLowerCase().includes('adsterra'));
  ok('WhatsApp CTA (B2B) मौजूद', /wa\.me\/919999999999/.test(idx));

  const wish = fs.readFileSync(R('wish.html'), 'utf8');
  ok('wish.html noindex (duplicate content से बचाव)', /noindex/.test(wish));
  ok('wish.html में ad slot है', /adsbygoogle/.test(wish));
  ok('wish.html में "ये भी भेजो" CTA दोनों जगह', (wish.match(/ये भी भेजो/g) || []).length >= 2);

  const readme = fs.readFileSync(R('README.md'), 'utf8');
  ok('README में deploy steps', /GitHub Pages/.test(readme) && /Steps?\s*2|Step 3/.test(readme));
  ok('README में monetization + B2B pitch', /Adsterra/.test(readme) && /pitch/i.test(readme));
  ok('README में domain replace instruction', /sed -i/.test(readme));
}

/* ==================== REPORT ==================== */
console.log('\n══════════════════════════════════════════');
for (const [s, n, e] of results) {
  if (s === '──') { console.log('\n' + n); continue; }
  console.log(`${s} ${n}${e ? '  →  ' + e : ''}`);
}
console.log('\n══════════════════════════════════════════');
console.log(`PASS: ${pass}   FAIL: ${fail}`);
if (errors.length) { console.log('\n⚠️ JS errors:'); errors.forEach(e => console.log('   ' + e)); }
else console.log('JS errors: ✅ none');
console.log('══════════════════════════════════════════');
process.exit(fail || errors.length ? 1 : 0);
})();
