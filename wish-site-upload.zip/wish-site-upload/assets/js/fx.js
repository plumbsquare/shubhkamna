/* ==========================================================
   FX ENGINE  —  canvas fireworks + confetti (zero dependency)
   ========================================================== */
(function (global) {
  'use strict';

  function FX(canvas) {
    this.c = canvas;
    this.ctx = canvas.getContext('2d');
    this.parts = [];
    this.raf = null;
    this.dpr = Math.min(global.devicePixelRatio || 1, 2);
    this.resize();
    var self = this;
    global.addEventListener('resize', function () { self.resize(); });
  }

  FX.prototype.resize = function () {
    var w = this.c.clientWidth || global.innerWidth;
    var h = this.c.clientHeight || global.innerHeight;
    this.c.width = w * this.dpr;
    this.c.height = h * this.dpr;
    this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    this.W = w; this.H = h;
  };

  FX.prototype.hex = function (c) {
    var m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(c);
    if (!m) return [255, 220, 120];
    return [parseInt(m[1], 16), parseInt(m[2], 16), parseInt(m[3], 16)];
  };

  /* ---- firework burst ---- */
  FX.prototype.burst = function (x, y, color, opts) {
    opts = opts || {};
    var rgb = this.hex(color || '#f5c451');
    var n = opts.count || 60;
    var speed = opts.speed || 4.6;
    for (var i = 0; i < n; i++) {
      var a = (Math.PI * 2 * i) / n + Math.random() * 0.3;
      var v = speed * (0.45 + Math.random() * 0.75);
      this.parts.push({
        x: x, y: y,
        vx: Math.cos(a) * v, vy: Math.sin(a) * v,
        life: 1, decay: 0.008 + Math.random() * 0.012,
        r: 1.4 + Math.random() * 2.1,
        col: [rgb[0], rgb[1], rgb[2]], type: 'spark',
        trail: true
      });
    }
    /* white core */
    for (var j = 0; j < 10; j++) {
      var a2 = Math.random() * Math.PI * 2;
      this.parts.push({
        x: x, y: y, vx: Math.cos(a2) * 1.2, vy: Math.sin(a2) * 1.2,
        life: 1, decay: 0.05, r: 3.2, col: [255, 255, 245], type: 'spark'
      });
    }
    this.start();
  };

  /* ---- confetti / glitter rain ---- */
  FX.prototype.confetti = function (count) {
    var cols = ['#f5c451', '#ff9a3c', '#ff5e7a', '#ffe9a8', '#8affc1', '#ffffff'];
    for (var i = 0; i < (count || 70); i++) {
      this.parts.push({
        x: Math.random() * this.W,
        y: -20 - Math.random() * 120,
        vx: (Math.random() - 0.5) * 2.4,
        vy: 2 + Math.random() * 3.6,
        life: 1, decay: 0.0035,
        r: 3 + Math.random() * 4,
        col: this.hex(cols[Math.floor(Math.random() * cols.length)]),
        type: 'conf', rot: Math.random() * Math.PI, vr: (Math.random() - 0.5) * 0.25,
        w: 4 + Math.random() * 5, h: 6 + Math.random() * 8
      });
    }
    this.start();
  };

  /* ---- combined celebration ---- */
  FX.prototype.celebrate = function (x, y, color) {
    this.burst(x, y, color || '#f5c451', { count: 70, speed: 5 });
    setTimeout(function () { this.burst(x - 90, y + 40, '#ff5e7a', { count: 40, speed: 3.8 }); }.bind(this), 220);
    setTimeout(function () { this.burst(x + 95, y - 30, '#8affc1', { count: 40, speed: 3.8 }); }.bind(this), 430);
    this.confetti(60);
  };

  FX.prototype.start = function () {
    if (this.raf) return;
    var self = this;
    var loop = function () {
      self.ctx.clearRect(0, 0, self.W, self.H);
      var alive = 0;
      for (var i = 0; i < self.parts.length; i++) {
        var p = self.parts[i];
        p.life -= p.decay;
        if (p.life <= 0) continue;
        alive++;

        if (p.type === 'conf') {
          p.vy += 0.045; p.x += p.vx; p.y += p.vy; p.rot += p.vr;
          p.vx *= 0.995;
        } else {
          p.vy += 0.085; p.vx *= 0.982; p.vy *= 0.982;
          p.x += p.vx; p.y += p.vy;
        }

        var a = Math.max(0, p.life);
        if (p.type === 'conf') {
          this.ctx.save();
          this.ctx.translate(p.x, p.y); this.ctx.rotate(p.rot);
          this.ctx.fillStyle = 'rgba(' + p.col[0] + ',' + p.col[1] + ',' + p.col[2] + ',' + a + ')';
          this.ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
          this.ctx.restore();
        } else {
          this.ctx.beginPath();
          this.ctx.fillStyle = 'rgba(' + p.col[0] + ',' + p.col[1] + ',' + p.col[2] + ',' + a + ')';
          this.ctx.arc(p.x, p.y, p.r * a + 0.4, 0, Math.PI * 2);
          this.ctx.fill();
          if (p.trail) {
            this.ctx.beginPath();
            this.ctx.fillStyle = 'rgba(' + p.col[0] + ',' + p.col[1] + ',' + p.col[2] + ',' + (a * 0.22) + ')';
            this.ctx.arc(p.x - p.vx * 2.2, p.y - p.vy * 2.2, p.r * a * 0.8, 0, Math.PI * 2);
            this.ctx.fill();
          }
        }
      }
      this.parts = this.parts.filter(function (p) { return p.life > 0; });
      if (alive > 0) { self.raf = global.requestAnimationFrame(loop); }
      else { self.raf = null; self.ctx.clearRect(0, 0, self.W, self.H); }
    }.bind(this);
    this.raf = global.requestAnimationFrame(loop);
  };

  global.FX = FX;
})(window);
