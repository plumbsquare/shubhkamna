/* ==========================================================
   AUDIO  —  browser me synth-generated festive loop.
   Koi audio file nahi, koi copyright nahi, 0 bytes.
   (Mobile pe autoplay block hota hai — isliye user gesture pe start)
   ========================================================== */
(function (global) {
  'use strict';

  function FestiveAudio() {
    this.ctx = null;
    this.master = null;
    this.timer = null;
    this.playing = false;
    this.step = 0;
    this.volume = 0.22;
    this.mode = 'celebrate';
  }

  /* Raga-y pentatonic (bright, festive) — C D E G A */
  FestiveAudio.prototype.SCALE = [261.63, 293.66, 329.63, 392.00, 440.00, 523.25, 587.33, 659.25];

  FestiveAudio.prototype.init = function () {
    if (this.ctx) return;
    var AC = global.AudioContext || global.webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = this.volume;

    // soft echo
    var delay = this.ctx.createDelay(1.0);
    delay.delayTime.value = 0.24;
    var fb = this.ctx.createGain(); fb.gain.value = 0.28;
    var wet = this.ctx.createGain(); wet.gain.value = 0.3;
    var lp = this.ctx.createBiquadFilter();
    lp.type = 'lowpass'; lp.frequency.value = 2400;

    this.master.connect(this.ctx.destination);
    this.master.connect(delay);
    delay.connect(fb); fb.connect(delay);
    delay.connect(lp); lp.connect(wet); wet.connect(this.ctx.destination);
  };

  FestiveAudio.prototype.note = function (freq, when, dur, type, gain) {
    if (!this.ctx) return;
    var o = this.ctx.createOscillator();
    var g = this.ctx.createGain();
    o.type = type || 'triangle';
    o.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, when);
    g.gain.exponentialRampToValueAtTime(gain || 0.22, when + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, when + dur);
    o.connect(g); g.connect(this.master);
    o.start(when); o.stop(when + dur + 0.05);
  };

  FestiveAudio.prototype.bell = function (freq, when) {
    if (!this.ctx) return;
    var o = this.ctx.createOscillator(); var g = this.ctx.createGain();
    o.type = 'sine'; o.frequency.value = freq * 2;
    g.gain.setValueAtTime(0.0001, when);
    g.gain.exponentialRampToValueAtTime(0.16, when + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, when + 1.4);
    o.connect(g); g.connect(this.master);
    o.start(when); o.stop(when + 1.5);
  };

  FestiveAudio.prototype.dhol = function (when) {
    if (!this.ctx) return;
    var o = this.ctx.createOscillator(); var g = this.ctx.createGain();
    o.type = 'sine';
    o.frequency.setValueAtTime(150, when);
    o.frequency.exponentialRampToValueAtTime(48, when + 0.16);
    g.gain.setValueAtTime(0.5, when);
    g.gain.exponentialRampToValueAtTime(0.0001, when + 0.26);
    o.connect(g); g.connect(this.master);
    o.start(when); o.stop(when + 0.3);
  };

  /* 8-step pattern */
  FestiveAudio.prototype.tick = function () {
    if (!this.ctx || !this.playing) return;
    var t = this.ctx.currentTime + 0.02;
    var s = this.step % 8;
    var S = this.SCALE;

    var pat = [0, 2, 4, 2, 5, 4, 2, 0];
    var note = S[pat[s] % S.length];
    this.note(note, t, 0.42, 'triangle', 0.2);
    this.note(note * 2, t, 0.26, 'sine', 0.08);

    if (s % 2 === 0) this.dhol(t);
    if (s === 0 || s === 5) this.bell(S[(pat[s] + 3) % S.length], t + 0.02);
    if (s === 3 || s === 6) this.note(S[(pat[s] + 2) % S.length] * 1.5, t + 0.16, 0.3, 'sine', 0.1);

    this.step++;
  };

  FestiveAudio.prototype.play = function () {
    this.init();
    if (!this.ctx) return false;
    if (this.ctx.state === 'suspended') this.ctx.resume();
    if (this.playing) return true;
    this.playing = true;
    this.master.gain.cancelScheduledValues(this.ctx.currentTime);
    this.master.gain.setValueAtTime(0.0001, this.ctx.currentTime);
    this.master.gain.exponentialRampToValueAtTime(this.volume, this.ctx.currentTime + 1.2);
    this.tick();
    this.timer = setInterval(this.tick.bind(this), 340);
    return true;
  };

  FestiveAudio.prototype.stop = function () {
    if (!this.ctx || !this.playing) return;
    this.playing = false;
    clearInterval(this.timer); this.timer = null;
    var t = this.ctx.currentTime;
    this.master.gain.cancelScheduledValues(t);
    this.master.gain.setValueAtTime(this.master.gain.value, t);
    this.master.gain.exponentialRampToValueAtTime(0.0001, t + 0.5);
  };

  FestiveAudio.prototype.toggle = function () {
    if (this.playing) { this.stop(); return false; }
    this.play(); return true;
  };

  global.FestiveAudio = FestiveAudio;
})(window);
