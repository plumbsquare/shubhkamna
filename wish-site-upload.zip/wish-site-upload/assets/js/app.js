/* ==========================================================
   CREATOR APP  —  index.html logic
   ========================================================== */
(function () {
  'use strict';

  var el = function (id) { return document.getElementById(id); };
  var sel = 'diwali';
  var tmr = null;

  /* ---------- festival grid ---------- */
  var grid = el('festGrid');
  festList().forEach(function (item) {
    var d = document.createElement('div');
    d.className = 'fest';
    d.dataset.key = item.key;
    d.setAttribute('role', 'radio');
    d.setAttribute('aria-label', item.f.name);
    d.innerHTML = '<span class="ic">' + item.f.icon + '</span><span class="nm">' + item.f.name + '</span>';
    d.addEventListener('click', function () {
      sel = item.key;
      Array.prototype.forEach.call(grid.children, function (c) { c.classList.remove('active'); c.setAttribute('aria-checked', 'false'); });
      d.classList.add('active');
      d.setAttribute('aria-checked', 'true');
      setThemeVars(item.f.theme);
      update();
      el('previewHint').textContent = 'Preview: ' + item.f.name;
    });
    grid.appendChild(d);
  });

  function selectFestival(key, silent) {
    var node = grid.querySelector('[data-key="' + key + '"]');
    if (!node) return;
    Array.prototype.forEach.call(grid.children, function (c) { c.classList.remove('active'); c.setAttribute('aria-checked', 'false'); });
    node.classList.add('active');
    node.setAttribute('aria-checked', 'true');
    sel = key;
    setThemeVars(FESTIVALS[key].theme);
    el('previewHint').textContent = 'Preview: ' + FESTIVALS[key].name;
    if (!silent) update();
  }

  /* ---------- state ---------- */
  // NFC normalization: same name → same link (legacy/non-composed Devanagari को canonical बनाता है)
  function norm(s) {
    s = (s || '').trim();
    try { return s.normalize('NFC'); } catch (e) { return s; }
  }
  function currentState() {
    return {
      f: sel,
      n: norm(el('inName').value),
      m: norm(el('inMsg').value),
      b: norm(el('inFrom').value)
    };
  }

  function baseUrl() {
    return location.origin + location.pathname.replace(/index\.html$/, '');
  }

  function buildLink() {
    var s = currentState();
    if (!s.n) s.n = 'दोस्त';
    return baseUrl() + 'wish.html#' + packState(s);
  }

  function update() {
    clearTimeout(tmr);
    tmr = setTimeout(function () {
      var s = currentState();
      el('frame').src = 'wish.html#' + packState(s);
    }, 350);
  }

  /* ---------- character counters ---------- */
  function bindCounter(inputId, counterId, max) {
    var inp = el(inputId), c = el(counterId);
    if (!inp || !c) return;
    var paint = function () {
      var n = inp.value.length;
      c.textContent = n + '/' + max;
      c.classList.toggle('warn', n > max - 15);
    };
    inp.addEventListener('input', paint);
    paint();
  }

  /* ---------- init (hash prefill) ---------- */
  var h = getState();
  if (h.f && FESTIVALS[h.f]) selectFestival(h.f, true);
  else selectFestival('diwali', true);
  if (h.n) el('inName').value = h.n;
  if (h.m) el('inMsg').value = h.m;
  if (h.b) el('inFrom').value = h.b;

  bindCounter('inName', 'cntName', 40);
  bindCounter('inFrom', 'cntFrom', 40);
  bindCounter('inMsg', 'cntMsg', 220);

  /* ---------- inputs ---------- */
  ['inName', 'inMsg', 'inFrom'].forEach(function (id) {
    el(id).addEventListener('input', update);
  });

  /* ---------- generate ---------- */
  function generate() {
    var s = currentState();
    if (!s.n) {
      el('inName').focus();
      toast('कम से कम नाम तो डालो 🙂');
      return;
    }
    var link = buildLink();
    el('result').style.display = 'block';
    el('outLink').value = link;
    el('waShare').href = 'https://wa.me/?text=' + encodeURIComponent('🪔 ' + s.n + ' ' + FESTIVALS[sel].title + '\n' + (s.m || '') + '\n\n👉 यहाँ खोलो: ' + link);
    el('openBtn2').href = link;
    saveHistory(s, link);
    if (el('result').scrollIntoView) el('result').scrollIntoView({ behavior: 'smooth', block: 'center' });
    toast('लिंक तैयार है! 🎉');
  }
  el('makeBtn').addEventListener('click', generate);

  /* Enter key from name field → generate */
  el('inName').addEventListener('keydown', function (e) {
    if (e.key === 'Enter') { e.preventDefault(); generate(); }
  });

  /* ---------- copy ---------- */
  function copyText(v, done) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(v).then(done).catch(function () { fallback(); });
    } else fallback();
    function fallback() {
      try {
        var ta = document.createElement('textarea');
        ta.value = v; ta.style.position = 'fixed'; ta.style.opacity = '0';
        document.body.appendChild(ta); ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        done();
      } catch (e) { toast('कॉपी नहीं हो पाया — लिंक manually चुनो'); }
    }
  }

  el('copyBtn2').addEventListener('click', function () {
    copyText(el('outLink').value, function () { toast('कॉपी हो गया ✅'); });
  });

  /* ---------- history ---------- */
  var HIST = 'wishlink_history_v1';
  function saveHistory(s, link) {
    try {
      var arr = JSON.parse(localStorage.getItem(HIST) || '[]');
      arr.unshift({ f: s.f, n: s.n, m: s.m, b: s.b, link: link, t: Date.now() });
      arr = arr.slice(0, 12);
      localStorage.setItem(HIST, JSON.stringify(arr));
      renderHistory();
    } catch (e) {}
  }
  function renderHistory() {
    var box = el('histList');
    var arr = [];
    try { arr = JSON.parse(localStorage.getItem(HIST) || '[]'); } catch (e) {}
    if (!arr.length) { box.innerHTML = '<div class="hint-txt" style="color:#7f7390;font-size:12.5px">अभी कोई लिंक नहीं बनाया।</div>'; return; }
    box.innerHTML = '';
    arr.forEach(function (it) {
      var f = FESTIVALS[it.f] || FESTIVALS.diwali;
      var row = document.createElement('div'); row.className = 'hist-item';
      row.innerHTML =
        '<span class="hi-ic">' + f.icon + '</span>' +
        '<span class="hi-txt"><b>' + escapeHtml(it.n || 'दोस्त') + '</b><span>' + escapeHtml(it.m || f.title) + (it.b ? ' — ' + escapeHtml(it.b) : '') + '</span></span>' +
        '<button class="btn ghost sm" data-act="copy">कॉपी</button>' +
        '<a class="btn ghost sm" href="' + it.link + '" target="_blank" rel="noopener">खोलें</a>';
      row.querySelector('[data-act="copy"]').addEventListener('click', function () {
        copyText(it.link, function () { toast('कॉपी हो गया ✅'); });
      });
      box.appendChild(row);
    });
  }
  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  el('clearHist').addEventListener('click', function () {
    localStorage.removeItem(HIST); renderHistory(); toast('हिस्ट्री साफ़ हो गई');
  });

  /* ---------- toast ---------- */
  var toastT = null;
  function toast(msg) {
    var t = el('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastT);
    toastT = setTimeout(function () { t.classList.remove('show'); }, 1900);
  }

  /* ---------- back to top ---------- */
  var toTop = el('toTop');
  if (toTop) {
    window.addEventListener('scroll', function () {
      toTop.classList.toggle('show', window.scrollY > 420);
    }, { passive: true });
    toTop.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  /* ---------- footer year ---------- */
  var yr = el('yr');
  if (yr) yr.textContent = String(new Date().getFullYear());

  renderHistory();
  update();
})();
