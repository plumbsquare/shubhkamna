/* ==========================================================
   WISH PAGE  —  recipient experience controller
   ========================================================== */
(function () {
  'use strict';

  var st = getState();
  var key = st.f && FESTIVALS[st.f] ? st.f : 'diwali';
  var F = FESTIVALS[key];

  var el = function (id) { return document.getElementById(id); };
  var stage = el('stage');

  /* ---------- theme ---------- */
  setThemeVars(F.theme);

  /* ---------- static copy ---------- */
  el('fTitle').textContent = F.title;
  el('fSub').textContent = F.subtitle;
  el('fTag').textContent = st.t || F.tagline;

  var nameEl = el('fName');
  nameEl.innerHTML = '';
  nameEl.appendChild(document.createTextNode(st.n || 'दोस्त'));
  var sheen = document.createElement('span');
  sheen.className = 'sheen';
  nameEl.appendChild(sheen);

  el('fFrom').innerHTML = st.b ? ('— <b>' + escapeHtml(st.b) + '</b>') : '';
  document.title = (st.n ? st.n + ' ' : '') + F.title + ' | शुभकामना';

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  /* ---------- build scene ---------- */
  var scene = el('scene');

  // stars
  if (!F.scene.sunrise) {
    var stars = document.createElement('div'); stars.className = 'stars';
    for (var i = 0; i < 70; i++) {
      var s = document.createElement('div'); s.className = 'star';
      s.style.left = Math.random() * 100 + '%';
      s.style.top = Math.random() * 62 + '%';
      s.style.animationDelay = (Math.random() * 3.4) + 's';
      var sz = 1 + Math.random() * 2.2;
      s.style.width = sz + 'px'; s.style.height = sz + 'px';
      stars.appendChild(s);
    }
    scene.appendChild(stars);
  }

  if (F.scene.moon) { var m = document.createElement('div'); m.className = 'moon'; scene.appendChild(m); }
  if (F.scene.crescent) { var c = document.createElement('div'); c.className = 'crescent'; scene.appendChild(c); }
  if (F.scene.sunrise) {
    var sr = document.createElement('div'); sr.className = 'sunrise'; scene.appendChild(sr);
    var rays = document.createElement('div'); rays.className = 'rays'; scene.appendChild(rays);
    for (var b = 0; b < 5; b++) {
      var bd = document.createElement('div'); bd.className = 'bird';
      bd.textContent = '🕊';
      bd.style.bottom = (18 + b * 7) + '%';
      bd.style.animationDelay = (b * 4.2) + 's';
      scene.appendChild(bd);
    }
  }
  if (F.scene.garland) { var g = document.createElement('div'); g.className = 'garland'; scene.appendChild(g); }
  if (F.scene.tilak) { var t = document.createElement('div'); t.className = 'tilak'; t.textContent = '🕉'; scene.appendChild(t); }
  if (F.scene.cake) { var ck = document.createElement('div'); ck.className = 'cake'; ck.textContent = '🎂'; scene.appendChild(ck); }

  // diyas
  if (F.scene.diyas) {
    var wrap = document.createElement('div'); wrap.className = 'diyas';
    var pos = [8, 20, 32, 68, 80, 92];
    pos.forEach(function (p, idx) {
      var d = document.createElement('div'); d.className = 'diya';
      d.style.left = p + '%';
      d.style.bottom = (2 + (idx % 3) * 1.6) + '%';
      d.style.transform = 'translateX(-50%) scale(' + (0.72 + (idx % 3) * 0.16) + ')';
      d.innerHTML = '<div class="flame' + (idx % 3 === 1 ? ' b' : idx % 3 === 2 ? ' c' : '') + '"></div><div class="bowl"></div>';
      wrap.appendChild(d);
    });
    scene.appendChild(wrap);
  }

  // rangoli
  if (F.scene.rangoli) {
    var rg = document.createElement('div'); rg.className = 'rangoli';
    var petals = '';
    for (var k = 0; k < 16; k++) {
      var a = (k * 22.5) * Math.PI / 180;
      var x1 = 120 + Math.cos(a) * 32, y1 = 120 + Math.sin(a) * 32;
      var x2 = 120 + Math.cos(a) * 112, y2 = 120 + Math.sin(a) * 112;
      petals += '<line class="draw" x1="' + x1.toFixed(1) + '" y1="' + y1.toFixed(1) + '" x2="' + x2.toFixed(1) + '" y2="' + y2.toFixed(1) + '"/>';
      petals += '<circle class="draw draw2" cx="' + x2.toFixed(1) + '" cy="' + y2.toFixed(1) + '" r="7"/>';
    }
    for (var ring = 1; ring <= 3; ring++) {
      petals += '<circle class="draw" cx="120" cy="120" r="' + (ring * 34) + '"/>';
    }
    rg.innerHTML = '<svg viewBox="0 0 240 240">' + petals + '</svg>';
    scene.appendChild(rg);
  }

  // embers
  var emb = document.createElement('div'); emb.className = 'embers';
  for (var e = 0; e < 26; e++) {
    var em = document.createElement('div'); em.className = 'ember';
    em.style.left = Math.random() * 100 + '%';
    em.style.setProperty('--dx', (Math.random() * 90 - 45) + 'px');
    em.style.animationDuration = (7 + Math.random() * 8) + 's';
    em.style.animationDelay = (Math.random() * 9) + 's';
    var es = 2 + Math.random() * 3.4;
    em.style.width = es + 'px'; em.style.height = es + 'px';
    emb.appendChild(em);
  }
  scene.appendChild(emb);

  // holi splashes
  if (F.scene.holi) {
    var cols = ['#ff5e7a', '#4ecdc4', '#ffe66d', '#8affc1', '#a06bff', '#ff9a3c'];
    for (var h = 0; h < 7; h++) {
      var sp = document.createElement('div'); sp.className = 'holi-splash';
      var cc = cols[h % cols.length];
      sp.style.background = cc;
      sp.style.width = sp.style.height = (90 + Math.random() * 150) + 'px';
      sp.style.left = (Math.random() * 90) + '%';
      sp.style.top = (10 + Math.random() * 60) + '%';
      sp.style.animationDelay = (h * 1.2) + 's';
      scene.appendChild(sp);
    }
  }

  // hearts
  if (F.scene.hearts) {
    var hs = ['💖', '💕', '💗', '💘', '💝'];
    for (var hh = 0; hh < 16; hh++) {
      var ht = document.createElement('div'); ht.className = 'heart';
      ht.textContent = hs[hh % hs.length];
      ht.style.left = Math.random() * 96 + '%';
      ht.style.bottom = '-20px';
      ht.style.animationDuration = (9 + Math.random() * 9) + 's';
      ht.style.animationDelay = (Math.random() * 10) + 's';
      scene.appendChild(ht);
    }
  }

  // coins
  if (F.scene.coins) {
    for (var cn = 0; cn < 12; cn++) {
      var co = document.createElement('div'); co.className = 'coin';
      co.textContent = '🪙';
      co.style.left = Math.random() * 94 + '%';
      co.style.bottom = '-20px';
      co.style.animationDuration = (10 + Math.random() * 10) + 's';
      co.style.animationDelay = (Math.random() * 12) + 's';
      scene.appendChild(co);
    }
  }

  // countdown
  if (F.scene.countdown) {
    var cd = document.createElement('div'); cd.className = 'countdown'; cd.id = 'cd';
    scene.appendChild(cd);
    updateCd();
    setInterval(updateCd, 1000);
  }
  function updateCd() {
    var n = new Date(); var t = new Date(n.getFullYear(), n.getMonth(), n.getDate() + 1, 0, 0, 5);
    var d = Math.max(0, t - n);
    var hh = String(Math.floor(d / 3600000)).padStart(2, '0');
    var mm = String(Math.floor(d / 60000) % 60).padStart(2, '0');
    var ss = String(Math.floor(d / 1000) % 60).padStart(2, '0');
    var e2 = el('cd'); if (e2) e2.textContent = hh + ' : ' + mm + ' : ' + ss;
  }

  /* ---------- canvas fx ---------- */
  var fx = new FX(el('fx'));

  /* ---------- audio ---------- */
  var audio = new FestiveAudio();
  var musicBtn = el('musicBtn');
  musicBtn.addEventListener('click', function (e) {
    e.stopPropagation();
    var on = audio.toggle();
    musicBtn.textContent = on ? '🔊' : '🔇';
    musicBtn.setAttribute('aria-label', on ? 'संगीत बंद करें' : 'संगीत चालू करें');
  });

  /* ---------- curtain + reveal ---------- */
  var curtain = el('curtain');
  var opened = false;
  function openCurtain() {
    if (opened) return;
    opened = true;
    curtain.classList.add('open');
    setTimeout(function () {
      curtain.style.display = 'none';
      el('fName').classList.add('reveal');
      typeMessage(st.m || F.tagline);
      // नाम सामने आते ही एक बड़ी आतिशबारी
      try {
        fx.burst(window.innerWidth / 2, window.innerHeight * 0.34, F.theme.gold, { count: 55, speed: 4.2 });
      } catch (e) {}
    }, 700);
  }
  curtain.addEventListener('click', function () {
    if (!audio.playing) { audio.play(); musicBtn.textContent = '🔊'; }
    hideHint();
    openCurtain();
  });
  setTimeout(openCurtain, 1400);   // auto-open fallback (tap is faster)

  function typeMessage(text) {
    var target = el('fMsg');
    if (!text) { target.textContent = ''; return; }
    var chars = Array.from(text);           // emoji/surrogate safe
    var i = 0;
    target.innerHTML = '<span class="cursor"></span>';
    var cur = target.querySelector('.cursor');
    var timer = setInterval(function () {
      cur.insertAdjacentText('beforebegin', chars[i] || '');
      i++;
      if (i >= chars.length) { clearInterval(timer); cur.remove(); }
    }, 26);
  }

  /* ---------- tap to celebrate ---------- */
  var lastBurst = 0;
  function celebrateAt(x, y) {
    var now = Date.now();
    if (now - lastBurst < 260) return;
    lastBurst = now;
    fx.celebrate(x, y, F.theme.gold);
  }

  var hintEl = document.querySelector('.hint-tap');
  function hideHint() { if (hintEl) hintEl.style.display = 'none'; }

  stage.addEventListener('click', function (ev) {
    if (ev.target.closest('button, a, input, label, .act')) return;
    if (!audio.playing) { audio.play(); musicBtn.textContent = '🔊'; }
    hideHint();
    celebrateAt(ev.clientX, ev.clientY);
  });

  el('celebrateBtn').addEventListener('click', function (ev) {
    ev.stopPropagation();
    if (!audio.playing) { audio.play(); musicBtn.textContent = '🔊'; }
    hideHint();
    celebrateAt(window.innerWidth / 2, window.innerHeight * 0.38);
  });

  /* ---------- photo (recipient's own photo, stays on device) ---------- */
  el('photoInput').addEventListener('change', function (e) {
    var f = e.target.files && e.target.files[0];
    if (!f) return;
    if (f.size > 6 * 1024 * 1024) { alert('फोटो 6MB से छोटी होनी चाहिए'); return; }
    var fr = new FileReader();
    fr.onload = function (ev) {
      var img = el('fPhoto');
      img.src = ev.target.result;
      img.style.display = 'block';
      el('photoBtn').textContent = 'फोटो बदलें';
    };
    fr.readAsDataURL(f);
  });
  el('photoBtn').addEventListener('click', function (e) { e.stopPropagation(); el('photoInput').click(); });

  /* ---------- share ---------- */
  var shareText = '🪔 ' + (st.n ? st.n + ' ' : '') + F.title + ' ' + F.subtitle +
    (st.m ? '\n' + st.m : '') + '\n\n👉 यहाँ खोलो: ' + location.href;

  el('waBtn').setAttribute('href', 'https://wa.me/?text=' + encodeURIComponent(shareText));
  el('shareBtn').addEventListener('click', function () {
    if (navigator.share) {
      navigator.share({ title: F.title, text: shareText, url: location.href }).catch(function () {});
    } else {
      copyText(location.href);
    }
  });
  el('copyBtn').addEventListener('click', function () { copyText(location.href); });

  function copyText(t) {
    if (navigator.clipboard) { navigator.clipboard.writeText(t).then(function () { toast('लिंक कॉपी हो गया ✅'); }); }
    else { toast('कॉपी नहीं हो पाया'); }
  }
  function toast(msg) {
    var t = el('toast'); t.textContent = msg; t.classList.add('show');
    setTimeout(function () { t.classList.remove('show'); }, 1900);
  }

  /* ---------- "ये भी भेजो" — viral loop ---------- */
  el('againBtn').setAttribute('href', 'index.html#f=' + key);
  el('againBtn2').addEventListener('click', function (ev) {
    ev.stopPropagation();
    location.href = 'index.html#f=' + key;
  });

  /* ---------- ambience ---------- */
  if (F.scene.fireworks) {
    setTimeout(function () {
      fx.burst(window.innerWidth * (0.2 + Math.random() * 0.6), window.innerHeight * (0.15 + Math.random() * 0.2), F.theme.gold, { count: 45, speed: 4 });
    }, 2200);
    setInterval(function () {
      if (document.hidden) return;
      fx.burst(window.innerWidth * (0.15 + Math.random() * 0.7), window.innerHeight * (0.12 + Math.random() * 0.25),
        [F.theme.gold, F.theme.gold2, F.theme.accent][Math.floor(Math.random() * 3)], { count: 38, speed: 3.6 });
    }, 6500);
  }

  /* ---------- first-visit auto music (needs gesture on mobile) ---------- */
  var greeted = false;
  function autoStart() {
    if (greeted) return; greeted = true;
    audio.play(); musicBtn.textContent = '🔊';
  }
  function autoStartHandler(ev) {
    if (ev.target && ev.target.closest && ev.target.closest('#musicBtn')) return;
    document.removeEventListener('touchstart', autoStartHandler);
    document.removeEventListener('mousedown', autoStartHandler);
    autoStart();
  }
  document.addEventListener('touchstart', autoStartHandler, { passive: true });
  document.addEventListener('mousedown', autoStartHandler);
})();
