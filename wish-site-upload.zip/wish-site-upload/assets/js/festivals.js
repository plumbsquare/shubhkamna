/* ============================================================
   FESTIVALS CONFIG  —  एक जगह से पूरा त्योहार जोड़/बदलें
   नया त्योहार जोड़ना हो तो यहाँ एक object जोड़ दो (README देखो)
   ============================================================ */
(function (global) {
  'use strict';

  var FESTIVALS = {
    diwali: {
      name: 'दिवाली',
      icon: '🪔',
      title: 'शुभ दीपावली',
      subtitle: 'Happy Diwali',
      tagline: 'दीयों की रोशनी आपके घर में खुशियों की महफ़िल ले आए',
      theme: {
        bg1: '#1a0512', bg2: '#2d0a1f', bg3: '#0d0209',
        gold: '#f5c451', gold2: '#ff9a3c', accent: '#ff5e7a',
        glow: 'rgba(245,196,81,.55)'
      },
      scene: { diyas: true, rangoli: true, moon: true, embers: true, fireworks: true, garland: true }
    },

    dhanteras: {
      name: 'धनतेरस',
      icon: '🪙',
      title: 'धनतेरस की हार्दिक शुभकामनाएँ',
      subtitle: 'Happy Dhanteras',
      tagline: 'धन लाभ, स्वास्थ्य और खुशियों की कामना',
      theme: {
        bg1: '#221003', bg2: '#3a1c05', bg3: '#120802',
        gold: '#ffd76e', gold2: '#e8a020', accent: '#ffb703',
        glow: 'rgba(255,215,110,.55)'
      },
      scene: { diyas: true, rangoli: false, moon: true, embers: true, fireworks: true, coins: true, garland: true }
    },

    bhai_dooj: {
      name: 'भाई दूज',
      icon: '🙏',
      title: 'भाई दूज की हार्दिक शुभकामनाएँ',
      subtitle: 'Happy Bhai Dooj',
      tagline: 'आपके भाई की जिंदगी में खुशियाँ और सफलता आए',
      theme: {
        bg1: '#2b0f04', bg2: '#43200a', bg3: '#160802',
        gold: '#ffc061', gold2: '#ff7a18', accent: '#ffd6a0',
        glow: 'rgba(255,122,24,.5)'
      },
      scene: { diyas: true, rangoli: true, moon: false, embers: true, fireworks: true, tilak: true, garland: true }
    },

    rakhi: {
      name: 'रक्षा बंधन',
      icon: '🧵',
      title: 'रक्षा बंधन की हार्दिक शुभकामनाएँ',
      subtitle: 'Happy Raksha Bandhan',
      tagline: 'आपकी राखी हमेशा आपको सुरक्षा देती रहे',
      theme: {
        bg1: '#1a0620', bg2: '#330a3d', bg3: '#0d0312',
        gold: '#ffb3d1', gold2: '#ff6f91', accent: '#ffd166',
        glow: 'rgba(255,111,145,.5)'
      },
      scene: { diyas: true, rangoli: true, moon: true, embers: true, fireworks: true, rakhi: true, garland: true }
    },

    holi: {
      name: 'होली',
      icon: '🎨',
      title: 'होली की हार्दिक बधाई',
      subtitle: 'Happy Holi',
      tagline: 'रंगों के इस त्योहार में आपकी जिंदगी रंग से भर आए',
      theme: {
        bg1: '#2b0b33', bg2: '#0d2a4a', bg3: '#14061c',
        gold: '#ffe66d', gold2: '#4ecdc4', accent: '#ff6b9d',
        glow: 'rgba(78,205,196,.5)'
      },
      scene: { diyas: false, rangoli: false, moon: false, embers: true, fireworks: true, holi: true, garland: false }
    },

    eid: {
      name: 'ईद',
      icon: '🌙',
      title: 'ईद की मुबारक',
      subtitle: 'Eid Mubarak',
      tagline: 'ईद का चांद आपकी हर दुआ को कबूल करे',
      theme: {
        bg1: '#05221c', bg2: '#0a3a30', bg3: '#02120f',
        gold: '#ffe9a8', gold2: '#7fd1ae', accent: '#f4d35e',
        glow: 'rgba(127,209,174,.5)'
      },
      scene: { diyas: false, rangoli: false, moon: true, embers: true, fireworks: true, crescent: true, garland: false }
    },

    newyear: {
      name: 'नव वर्ष',
      icon: '🎉',
      title: 'नव वर्ष की हार्दिक शुभकामनाएँ',
      subtitle: 'Happy New Year',
      tagline: 'नए साल में नई उम्मीदें, नई शुरुआत',
      theme: {
        bg1: '#050a26', bg2: '#0d1a4d', bg3: '#02040f',
        gold: '#ffe9a3', gold2: '#7ea6ff', accent: '#ff7ad9',
        glow: 'rgba(126,166,255,.5)'
      },
      scene: { diyas: false, rangoli: false, moon: false, embers: true, fireworks: true, countdown: true, garland: false }
    },

    goodmorning: {
      name: 'शुभ प्रभात',
      icon: '🌅',
      title: 'शुभ प्रभात',
      subtitle: 'Good Morning',
      tagline: 'आज का दिन आपके लिए खुशियों से भरा हो',
      theme: {
        bg1: '#3a1d08', bg2: '#8a4a12', bg3: '#1d0f05',
        gold: '#ffe9a8', gold2: '#ff9d4d', accent: '#ffd166',
        glow: 'rgba(255,157,77,.5)'
      },
      scene: { diyas: false, rangoli: false, moon: false, embers: true, fireworks: false, sunrise: true, birds: true, garland: false }
    },

    valentine: {
      name: 'वैलेंटाइन',
      icon: '💖',
      title: 'Happy Valentine’s Day',
      subtitle: 'Be My Valentine',
      tagline: 'आपको प्यार और खुशियाँ, हमेशा',
      theme: {
        bg1: '#2c0517', bg2: '#5a0b2b', bg3: '#15020b',
        gold: '#ffd6e0', gold2: '#ff5d8f', accent: '#ffb3c6',
        glow: 'rgba(255,93,143,.5)'
      },
      scene: { diyas: false, rangoli: false, moon: true, embers: true, fireworks: false, hearts: true, garland: false }
    },

    birthday: {
      name: 'जन्मदिन',
      icon: '🎂',
      title: 'Happy Birthday',
      subtitle: 'Many Happy Returns',
      tagline: 'आपकी जिंदगी हर दिन और खूबसूरत हो',
      theme: {
        bg1: '#141033', bg2: '#3d1b66', bg3: '#0a0620',
        gold: '#ffe08a', gold2: '#ff7ec4', accent: '#8affc1',
        glow: 'rgba(255,126,196,.5)'
      },
      scene: { diyas: false, rangoli: false, moon: false, embers: true, fireworks: true, cake: true, garland: true }
    },

    thanks: {
      name: 'शुक्रिया',
      icon: '🙏',
      title: 'धन्यवाद',
      subtitle: 'Thank You',
      tagline: 'आपके दिए हर एहसान के लिए दिल से शुक्रिया',
      theme: {
        bg1: '#08221a', bg2: '#0f4033', bg3: '#04120e',
        gold: '#ffe9a8', gold2: '#6fd6a8', accent: '#ffd166',
        glow: 'rgba(111,214,168,.5)'
      },
      scene: { diyas: true, rangoli: false, moon: true, embers: true, fireworks: false, garland: true }
    }
  };

  /* ---------- helpers ---------- */
  function festList() {
    return Object.keys(FESTIVALS).map(function (k) { return { key: k, f: FESTIVALS[k] }; });
  }

  /* State को URL hash में pack / unpack.
     हर link खुद में पूरा data लिए होता है — कोई server नहीं। */
  function packState(o) {
    var p = [];
    for (var k in o) {
      if (!Object.prototype.hasOwnProperty.call(o, k)) continue;
      if (o[k] === undefined || o[k] === null || o[k] === '') continue;
      p.push(encodeURIComponent(k) + '=' + encodeURIComponent(o[k]));
    }
    return p.join('&');
  }

  function unpackState(str) {
    var out = {};
    if (!str) return out;
    str = String(str).replace(/^[#?]/, '');
    str.split('&').forEach(function (pair) {
      if (!pair) return;
      var i = pair.indexOf('=');
      if (i < 0) return;
      var k = decodeURIComponent(pair.slice(0, i));
      var v = decodeURIComponent(pair.slice(i + 1));
      out[k] = v;
    });
    return out;
  }

  function getState() {
    var h = location.hash || '';
    if (h.charAt(0) === '#') h = h.slice(1);
    if (h.charAt(0) === '?') h = h.slice(1);
    return unpackState(h);
  }

  function setThemeVars(theme) {
    var r = document.documentElement.style;
    r.setProperty('--bg1', theme.bg1);
    r.setProperty('--bg2', theme.bg2);
    r.setProperty('--bg3', theme.bg3);
    r.setProperty('--gold', theme.gold);
    r.setProperty('--gold2', theme.gold2);
    r.setProperty('--accent', theme.accent);
    r.setProperty('--glow', theme.glow);
  }

  global.FESTIVALS = FESTIVALS;
  global.festList = festList;
  global.packState = packState;
  global.unpackState = unpackState;
  global.getState = getState;
  global.setThemeVars = setThemeVars;
})(window);
