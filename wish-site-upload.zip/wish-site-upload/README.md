# 🪔 शुभकामना — नाम के साथ एनिमेशन वाली शुभकामना लिंक

> **नाम डालो → एक लिंक मिलेगा → WhatsApp पर भेजो → खुलते ही पूरा स्क्रीन एनिमेशन, संगीत, दीये, आतिशबारी और नाम के साथ शुभकामना।**
> 100% फ्री · कोई ऐप नहीं · कोई सर्वर खर्च नहीं · हर लिंक अलग

यह **पूरी तरह static** साइट है (सिर्फ़ HTML + CSS + JS) — इसलिए सीधा **GitHub Pages** पर लाइव हो जाएगी, हर लिंक की **₹0 marginal cost** है, और 4G पर भी 2 सेकंड में खुलता है।

---

## 0. Quick start — 5 मिनट में लाइव 🚀

> 📄 **`START-HERE.md`** इस folder में है — वही सबसे छोटा और साफ़ guide है (3 रास्ते: drag&drop / एक command / सिर्फ़ domain)।

### 🅰️ सबसे आसान — Drag & Drop (सिर्फ़ browser)

| # | क्या करना है | कहाँ |
|---|---|---|
| 1 | **Repo name रखो:** `shubhkamna` (छोटा, lowercase, बिना space) | [github.com/new](https://github.com/new) |
| 2 | **Files upload:** zip extract करो → अंदर की **सारी files/folders** GitHub के upload box में drag & drop करो | Repo → *Add file* → *Upload files* |
| 3 | **Pages चालू करो:** Settings → Pages → Source = **"Deploy from a branch"** → Branch `main` → Folder `/ (root)` → Save | Repo → *Settings* → *Pages* |
| 4 | **1–2 मिनट बाद** site live: `https://<तुम्हारा-username>.github.io/shubhkamna/` | — |
| 5 | (optional लेकिन recommended) **Auto-deploy workflow:** `pages-workflow.yml` की content → *Add file → Create new file* → path `.github/workflows/pages.yml` → Commit | Repo → *Add file* |

### 🅱️ सबसे "set & forget" — एक Command

```bash
# zip extract करके उस folder में:
./setup.sh                              # repo: shubhkamna
./setup.sh my-wish-site                 # दूसरा नाम
./setup.sh my-wish-site shubhkamna.in   # + custom domain
```
Windows: `setup.bat` (same commands)

ये script **अपने आप** करता है: `_github`→`.github` rename → git init+commit → **repo बनाना + push** → **Pages enable** → (domain दिया हो तो) CNAME + secret + DNS guide → final links।

> ज़रूरी: [Git](https://git-scm.com/downloads) + [GitHub CLI `gh`](https://cli.github.com) installed होना चाहिए।

### 🅲️ Domain बदलना (बाद में)
Repo → Settings → Pages → Custom domain → DNS records (नीचे Section 3, Step 4 में पूरी table) → Enforce HTTPS ON।

### 🤖 Automation — workflow अपने आप क्या करता है

हर push पर: **🧪 TEST (75 assertions — fail हुआ तो deploy रुकेगा) → 🧹 PREPARE (URL/domain/ads inject) → 🌐 DEPLOY**

Secrets (Repo → Settings → Secrets and variables → Actions → New repository secret):

| Secret | क्या डालें | फ़ायदा |
|---|---|---|
| `CUSTOM_DOMAIN` | `shubhkamna.in` | CNAME + सारी URLs उसी domain पर, बदलते ही auto-update |
| `ADSTERRA_SCRIPT` | Adsterra का पूरा loader `<script>...</script>` | Ads अपने आप ad slots में |
| `ADSENSE_CLIENT` + `ADSENSE_SLOT` | `ca-pub-...` + slot id | AdSense block अपने आप active |
| `SITE_URL` | optional override | किसी और host पर ले जाना हो तो |

> Secret बदलते ही अगला push उन्हें inject कर देगा — **कोई code छूने की ज़रूरत नहीं।**

### 📌 Repo name क्यों `shubhkamna`?
- GitHub Pages URL = `https://<username>.github.io/<repo-name>/` — छोटा नाम = छोटा URL = WhatsApp में टाइप करना आसान
- सिर्फ़ lowercase अक्षर, numbers और `-`/`_` चलते हैं (space नहीं)
- `.git` लगा मत देना (`shubhkamna.git` ❌)
- अगर तुम्हें **root URL** चाहिए (`username.github.io` बिना folder) तो repo का नाम **`username.github.io`** रखना पड़ेगा
- Final (professional) look के लिए → **custom domain**: `shubhkamna.in` / `wishlink.in` (~₹700–1,200/yr)

---

## 1. क्या-क्या मिला है (Features)

| Feature | Detail |
|---|---|
| 🎆 11 त्योहार | दिवाली, धनतेरस, भाई दूज, रक्षा बंधन, होली, ईद, नव वर्ष, गुड मॉर्निंग, वैलेंटाइन, बर्थडे, थैंक्स |
| ✍️ नाम + मैसेज | नाम, अपना मैसेज, और "किससे" (from) — सब कुछ URL में encode होकर जाता है |
| 🎬 पूरा एनिमेशन | पर्दा खुलना, दीयों की रोशनी, आतिशबारी, कॉन्फेटी, टाइपराइटर मैसेज, नाम पर शीन |
| 🎵 संगीत | WebAudio से बनाया गया मुफ़्त त्योहारी ट्यून (कोई MP3 नहीं, कोई copyright नहीं) |
| 📸 फ़ोटो | रिसीवर अपनी फ़ोटो यहाँ अपलोड कर सकता है (सिर्फ़ उसके डिवाइस पर, कहीं upload नहीं) |
| 📲 WhatsApp share | एक tap पर WhatsApp खुलता है, टेक्स्ट पहले से भरा हुआ |
| 🔁 वायरल लूप | हर लिंक के नीचे "ये भी भेजो" CTA → रिसीवर खुद नया लिंक बनाता है |
| 📊 Ad slots | Adsterra / PropellerAds / PopAds / Monetag + AdSense के लिए तैयार स्लॉट |
| 📈 लोकल हिस्ट्री | बनाए हुए लिंक browser में save (localStorage) |
| 🔍 SEO | meta, Open Graph, sitemap, robots, 404 page — सब ready |

---

## 2. फ़ोल्डर संरचना (Folder structure)

```
wish-site/
├── index.html                  # ← जनरल पेज: नाम डालो → लिंक बनाओ (यही landing page है)
├── wish.html                   # ← रिसीवर वाला full-screen एनिमेशन पेज
├── 404.html                    # गलत लिंक पर सुंदर error page
├── robots.txt                  # crawler नियम
├── sitemap.xml                 # sitemap
├── CNAME.example               # custom domain (इसे copy करके CNAME बनाओ)
├── START-HERE.md               # ⭐ सबसे छोटा guide — 3 रास्ते (drag&drop / 1 command / domain)
├── setup.sh / setup.bat        # 🤖 एक command में: repo + push + Pages + domain
├── pages-workflow.yml          # workflow की copy (drag&drop रास्ते के लिए — path .github/workflows/pages.yml)
├── .github/
│   ├── workflows/pages.yml     # 🚀 test → prepare (URL/domain/ads inject) → deploy
│   └── prepare_site.py         # 🧹 real URL + CNAME + ad codes का automatic injection
├── tests/
│   ├── fulltest.js             # 🧪 75-assertion test suite (CI में भी चलता है)
│   └── package.json
├── assets/
│   ├── css/
│   │   ├── base.css            # जनरल पेज की styling
│   │   └── wish.css            # एनिमेशन पेज की styling
│   ├── js/
│   │   ├── festivals.js        # त्योहारों का data + theme + URL encode/decode
│   │   ├── app.js              # जनरल पेज की logic (grid, form, link, share)
│   │   ├── wish.js             # एनिमेशन पेज की logic (curtain, typewriter, photo, CTA)
│   │   ├── fx.js               # canvas पर आतिशबारी + कॉन्फेटी (zero dependency)
│   │   └── audio.js            # WebAudio से त्योहारी संगीत (zero dependency)
│   └── img/
│       ├── og.jpg              # 1200×630 WhatsApp/FB preview image
│       ├── og-bg.jpg           # og.jpg का source (optional, deploy size बढ़ाता है)
│       └── favicon.svg
```

**कोई build step नहीं, कोई npm नहीं, कोई backend नहीं।** सारे JS/CSS सीधे browser में चलते हैं।

---

## 3. GitHub Pages पर लाइव करो (Step by step)

### Step 1 — Repo बनाओ
1. [github.com/new](https://github.com/new) खोलो
2. Repo name: `shubhkamna` (या जो मन में आए)
3. ⚠️ **"Add a README file" ON, `.gitignore` = None, License = None** चुनो
4. **Create repository**

### Step 2 — Files upload करो

**Method A — बिना git (सबसे आसान, drag & drop)**

1. अपने computer में `wish-site` folder को **zip** करो
2. Repo page पर **"Add file" → "Upload files"** पर जाओ
3. Zip को **drag & drop** करो (या folder को अंदर तक खोलकर सारी files drop करो)
4. नीचे scroll करके **"Commit changes"** पर click करो

> 💡 Folder structure बराबर रहेगी — GitHub अंदर के folder को अपने आप बनाता है।
> ⚠️ **ध्यान दो:** browser drag & drop में **hidden folders (`.github`) ignore** हो जाते हैं — इसके 2 उपाय हैं:
>
> **उपाय 1 (सबसे आसान):** Pages → Source = **"Deploy from a branch"** चुन लो — workflow की ज़रूरत ही नहीं, site फिर भी लाइव हो जाएगी (बस हर बार push पर manually "Deploy to GitHub Pages" दबाना पड़ेगा)।
>
> **उपाय 2 (auto-deploy चाहिए तो):** zip extract करते समय `.github` folder को **`_github`** नाम से extract करो (hidden नहीं दिखेगा) → upload करो → GitHub में folder के नाम पर click करके **rename → `.github`** कर दो → फिर `pages.yml` में `branches: ["main"]` check कर लो (तुम्हारी branch master हो तो बदल दो)।
>
> **उपाय 3 (सबसे साफ़):** नीचे Method B (git + gh CLI) — एक command में सब कुछ, hidden files सहित।

**Method B — एक command (recommended — सब कुछ अपने आप) 🤖**

```bash
cd wish-site
./setup.sh                              # repo: shubhkamna
./setup.sh my-wish-site shubhkamna.in   # + custom domain
```
Windows: `setup.bat`

ये script repo बनाता है, push करता है, Pages चालू करता है, domain लगाता है — और सारे डिलीवरी links देता है।

**Method B2 — खुद git + gh**

Terminal में (git और `gh` install होने चाहिए):
```bash
cd wish-site
git init
git add -A
git commit -m "🚀 Shubhkamna v1 — animated greeting links"
gh auth login                # एक बार
gh repo create shubhkamna --public --source=. --remote=origin --push
```
बस — repo बन गया और सारी files (`.github` workflow सहित) push हो गईं। अब सिर्फ़ Step 3 करो।

> 🖥️ Git install नहीं है? [git-scm.com/downloads](https://git-scm.com/downloads) से install कर लो — या सीधे Method A + "Deploy from a branch" (Step 3) से भी चल जाएगा।

### Step 3 — Pages चालू करो
1. Repo में जाओ → **Settings** (tab)
2. बाईं तरफ **"Pages"** पर click करो
3. **"Source"** में चुनो: **Deploy from a branch**
   - Branch: **main** (या master — जो तुम्हारा repo default है)
   - Folder: **/ (root)**
4. **Save** करो
5. 1–2 मिनट में site live हो जाएगी 👉 `https://<username>.github.io/shubhkamna/`

> ✅ **Alternative (recommended):** repo में `.github/workflows/pages.yml` पहले से मौजूद है।
> Settings → Pages → Source = **"GitHub Actions"** चुन दो। अब हर `push` पर site अपने आप redeploy हो जाएगी।

### Step 4 — अपना domain लगाओ (optional, ~₹700–1,200/ साल)

**A. Domain खरीदो** — GoDaddy / Namecheap / Hostinger / BigRock (`.in` domain ~₹700–1,200/yr)

**B. DNS सेट करो** — domain के DNS में ये दो record डालो:

| Type | Host | Value |
|---|---|---|
| `CNAME` | `www` | `<username>.github.io` |
| `A` | `@` | `185.199.108.153` |
| `A` | `@` | `185.199.109.153` |
| `A` | `@` | `185.199.110.153` |
| `A` | `@` | `185.199.111.153` |

**C. CNAME file बनाओ**
```bash
cd wish-site
cp CNAME.example CNAME
# और अंदर अपना domain लिखो, जैसे: shubhkamna.in
```

**D. GitHub में** → Settings → Pages → **Custom domain** में अपना domain डालो → Save
→ "Enforce HTTPS" चालू कर दो (2 मिनट में green tick आ जाएगा)

### Step 5 — `example.com` को अपने domain से बदलो ⚠️ (ज़रूरी!)

`index.html`, `wish.html`, `robots.txt`, `sitemap.xml` में `example.com` लिखा है (Open Graph preview + canonical इसी से बनता है)।

```bash
cd wish-site
sed -i 's|https://example.com/|https://shubhkamna.in/|g' index.html wish.html robots.txt sitemap.xml
```

और अगर `github.io` वाला URL पर रहना है तो:
```bash
sed -i 's|https://example.com/|https://<username>.github.io/shubhkamna/|g' index.html wish.html robots.txt sitemap.xml
```

बदलने के बाद **commit + push** करो — deployment अपने आप हो जाएगा।

---

## 4. Monetization (कमाई कैसे लगाओ)

### 4.1 पहले दिन से चालू करो — Adsterra / PopAds / Monetag (Recommended)

ये networks **wishing/greeting sites को approve करते हैं** और तुरंत account मिल जाता है (min payout ~$5)।

| Network | क्या मिलता है | India CPM (approx) |
|---|---|---|
| **Adsterra** | Popunder, Social Bar, Native Banner | $0.10–$0.50 |
| **PropellerAds** | Popunder, Push-notif, Social bar | $0.05–$0.40 |
| **PopAds / Monetag / HilltopAds / AdsAgony** | Popunder, banner, native | $0.05–$0.35 |
| **RichAds / Mondiad** | Native + pop, सबसे safe bounce के लिए | $0.10–$0.60 |

**कैसे लगाओ:**
1. [adsterra.com](https://adsterra.com) पर account बनाओ (free, ~2 min) → **Creators → Adsterra for Websites** → "Add Website" → अपना domain डालो
2. Dashboard से **Popunder** का loader code copy करो (ये `<\/script>` के साथ आता है)
3. `index.html` में `<!-- Adsterra / Popunder slot -->` comment के ठीक नीचे paste कर दो
4. Same code `wish.html` के `<!-- ad slot (optional) -->` में भी डाल दो — **यही सबसे ज़्यादा views यहीं से आते हैं**
5. 24 घंटे बाद report check करो (impressions + RPM)

> ⚠️ **ज़रूरी:** एक visitor पर **एक से ज़्यादा popunder मत दिखाओ** — bounce rate 12% तक बढ़ जाता है और Adsterra account ही suspend हो सकता है। Social bar (bottom banner) सबसे safe option है।

### 4.2 AdSense (सच्चाई पहले बता देता हूँ)

- AdSense की policy में "greeting / wishing sites" पर approval मिलना **मुश्किल** है — कई बार reject हो जाता है (reason: "low value content" / "excessive advertising").
- **Strategy:** index.html (landing page) पर content + tutorials + FAQ डालकर AdSense apply करो; `wish.html` पर AdSense script **मत डालो** (वहाँ popunder/network रखो).
- Approved हो जाए तो India RPM **₹40–250 per 1000 views**; त्योहार के दिन mobile eCPM ~15% बढ़ जाता है।
- AdSense code कहाँ डालना है: `index.html` में `<!-- AdSense slot 1 -->` comment के ठीक नीचे `<ins class="adsbygoogle">` block paste करो और `<script async src="...adsbygoogle.js?client=ca-pub-XXXX">` लोड करो.

### 4.3 Ad-free (Paid Unlock) — ₹49–₹99

`wish.html` में एक छोटा button जोड़ो: *"Ads हटाओ — ₹49"*. Payment: UPI link (Razorpay Payment Link बनाकर `?name=` param से नाम भेज दो) — backend नहीं चाहिए, UPI deep link काम करता है।

### 4.4 Affiliate / Lead-gen (बिना ट्रैफिक बिगाड़े)

| Option | Commission |
|---|---|
| Diwali gift hamper / mithai box affiliate | 4–15% per order |
| Amazon / Flipkart affiliate link (गिफ़्ट सेक्शन) | 3–10% |
| WhatsApp lead (QR → आपका नंबर) | ₹20–₹100 per qualified lead |
| Local jewellery / sweet shop coupon | fixed ₹50–₹200 |

### 4.5 B2B — **सबसे बड़ी कमाई यहीं है** 🏆

Local brand (mithai shop, jewellery, clothes, mobile shop, gym, event manager) को **उनके brand + logo + offer के साथ बने हुए शुभकामना लिंक** बेचो। वो अपने ग्राहकों को WhatsApp पर भेजते हैं — आपको traffic मिलता है और बिना खर्च के।

| Package | Price | Kya milega |
|---|---|---|
| Starter | ₹2,999 | 1 त्योहार, 1 टेम्पलेट, logo + business name, WhatsApp share |
| Business | ₹6,999 | सभी त्योहार + custom message + photo + analytics, 2 साल |
| Premium | ₹9,999 – ₹24,999 | Exclusive theme, custom domain link, ad-free, coupon landing, priority support |

**2–5 clients × ₹10–25,000 = ₹20,000–1,25,000** — यही एक महीने में ads से ज़्यादा दे सकता है।

### 4.6 कमाई का अंदाज़ा (50,000 views)

| Source | Low | High |
|---|---|---|
| Ads (Adsterra + AdSense) | ₹750 | ₹12,500 |
| Paid unlock (₹49–₹99) | ₹500 | ₹9,900 |
| Affiliate / lead-gen | ₹3,000 | ₹9,000 |
| B2B branded links | ₹20,000 | ₹1,25,000 |
| **Total** | **₹26,000** | **₹1,58,000** |

> ⚠️ ये *potential* है, guarantee नहीं. असली पैसा B2B और distribution से आता है, ads से नहीं.

---

## 5. B2B WhatsApp pitch script (सीधे कॉपी-पेस्ट करो)

**Intro (दुकान/ऑफिस में):**
> "नमस्ते जी! मैं [नाम]। मैं एक ऐसी साइट बनाता हूँ जिससे आप अपने ग्राहकों को सिर्फ़ नाम लिखकर त्योहार की एनिमेशन वाली शुभकामना WhatsApp पर भेज सकते हैं — आपके लोगो और दुकान का नाम साथ में। कोई ऐप नहीं, ग्राहक को कुछ डाउनलोड नहीं करना, सीधा खुल जाती है।"

**Follow-up message (WhatsApp):**
> "🙏 {दुकान का नाम} के लिए एक शुभकामना लिंक बना दिया है — {1-2 लाइन preview}
> आप सीधे अपने ग्राहकों को भेज सकते हैं, नाम वो खुद डालेंगे।
> दिवाली/होली/जन्मदिन — जब भी चाहें, मैं 5 मिनट में नया बना दूँगा।
> पहले 1 हफ़्ते मुफ़्त है — बस बताइए आपका लोगो और दुकान का नाम क्या रखूँ? 🙏"

**Price message:**
> "पैकेज: ₹2,999 में 1 त्योहार (सारे ग्राहकों के लिए अलग नाम वाले लिंक), ₹6,999 में सारे त्योहार + आपका फ़ोटो + कस्टम मैसेज।
> आपका पैसा कोई app/serVer खर्च नहीं — आप सीधे WhatsApp से share करते हो, ग्राहक के फ़ोन में कुछ install नहीं होता।"

**Closing (soft close):**
> "अगर इस हफ़्ते 1 टेस्ट कर लें तो? बस अपना लोगो भेजिए, मैं 10 मिनट में लिंक बना कर भेज दूँगा — पसंद न आए तो पैसे नहीं।"

---

## 6. Distribution (ट्रैफिक कहाँ से लाओगा) — SEO से नहीं, **वायरल** से

1. **WhatsApp groups (सबसे बड़ा चैनल)** — 50–100 local groups (मोहल्ला, ऑफिस, कॉलेज, शेयरी समाज) में रोज़ 1 लिंक + बदलता-बदलता संदेश
2. **Reels / Shorts / YouTube Shorts** — 10 सेकंड का clip: "नाम डालो, शुभकामना लिंक तैयार" + स्क्रीन रिकॉर्डिंग
3. **Facebook groups** — शहर के "Diwali wishes" groups में लिंक (स्पैम मत करो, value दो)
4. **Status + Stories** — WhatsApp status पर रोज़ 2-3 बार, टाइमिंग सुबह 8–10 और रात 8–11
5. **Local दुकानों के लिए काम करो** (B2B) — वो अपने ग्राहकों को भेजेंगे, वो traffic free में लाएंगे
6. **QR code** — दुकान/कार्यालय में लगाओ, हर scan पर एक नया लिंक

> ⏰ **Timing:** दिवाली 2026 — दशहरा 20 Oct, धनतेरस 6 Nov, छोटी दिवाली 7 Nov, **दिवाली 8 Nov 2026**. त्योहार से 10–15 दिन पहले link बनाकर रखो, distribution त्योहार के दिन-दिन चलाओ.

---

## 7. Customization (इसे अपना बनाओ)

### नया त्योहार जोड़ना
`assets/js/festivals.js` खोलो → `FESTIVALS` object में नया entry जोड़ो:

```js
holi: {
  key: 'holi',
  title: 'होली',
  sub: 'Happy Holi',
  tagline: 'रंगों का त्योहार',
  defaultMsg: 'होली के रंग आपकी ज़िंदगी में छा जाएँ',
  emoji: '🎉',
  theme: { a: '#ff5f6d', b: '#ffc371', glow: '#ff8fa3' }   // रंग
}
```

बस — grid में दिख जाएगा, लिंक बन जाएगी, एनिमेशन रंग बदल जाएंगे।

### रंग / थीम बदलना
`festivals.js` में हर त्योहार के `theme` में `a`, `b`, `glow` — ये CSS variables (`--a`, `--b`, `--glow`) में जाते हैं।

### अपना संगीत
`assets/js/audio.js` — WebAudio oscillators से बनी धुन। अपनी धुन चाहिए तो वहाँ के note arrays बदल दो (कोई MP3/license नहीं चाहिए — यही असली फ़ायदा है).

### अपनी फ़ोटो जोड़ना
- **रिसीवर की फ़ोटो:** `wish.html` में already है (उसके डिवाइस पर, कहीं upload नहीं होती — privacy safe)
- **अपनी फ़ोटो (साइट वाले की):** `assets/js/festivals.js` में `photo: 'assets/img/me.jpg'` डालो → scene में दिखेगी

### नया त्योहार + नया message (ऐडिट करने लायक कोड)
सारा text `festivals.js` में है, JS में नहीं — बदलना आसान है।

---

## 8. Technical notes / सीमाएँ (ईमानदार सच)

| बात | Detail |
|---|---|
| **WhatsApp preview static है** | GitHub Pages static है, इसलिए हर नाम का अलग OG image नहीं बन सकता — सबका preview एक ही `og.jpg` दिखेगा. (नाम लिंक खोलने पर एनिमेशन में दिखता है, preview में नहीं) |
| **Link expiry नहीं** | कोई server नहीं ⇒ लिंक कभी expire नहीं होता (अच्छी बात), लेकिन बदलना भी नहीं हो सकता |
| **Sent/received analytics नहीं** | कितनों ने खोला — यह गिनना हो तो backend/shortener चाहिए |
| **बड़ा message (500+ chars)** | लंबा मैसेज URL बन जाता है; WhatsApp ~2000 char तक ठीक चलाता है |
| **iOS पर sound** | Sound browser gesture के बाद ही चलता है (auto-play policy) — button पर लगा है |
| **Ad-blockers** | कुछ लोग popunder block करते हैं — इसलिए CTA और share button पर focus रखो |
| **Privacy** | फ़ोटो + नाम सिर्फ़ user के device पर; कोई server, कोई data collect नहीं |

---

## 9. Troubleshooting

| Problem | Fix |
|---|---|
| WhatsApp में preview image नहीं दिख रहा | WhatsApp/Facebook preview **cache** करता है. `?v=2` जोड़कर नया link share करो, या Facebook Post Editor में link डालकर refresh करो. साथ में `og:image` **absolute URL** होना चाहिए (Step 5 किया हो तो ठीक) |
| Site live ही नहीं हो रहा | Actions tab में workflow run देखो; Pages Source = "GitHub Actions" या "Deploy from a branch" दोनों में से एक ही रखना है |
| Fonts (देवनागरी) अजीब दिख रहे | Google Fonts load नहीं हो रहा — internet check करो; font fallback `Noto Sans Devanagari, Nirmala UI, Mangal` है |
| Animation slow है | कम पुराने फ़ोन पर canvas heavy हो सकता है — `fx.js` में particle count घटाओ (`MAX` constant) |
| Adsterra account suspend | एक visitor पर 2 popunder मत दिखाओ; traffic source पर शक हो तो pause कर दो |
| कुछ नाम (emoji, `&`, quotes) टूट रहे हैं | टेस्ट में verify हो चुका है ✅; अगर फिर भी issue हो तो `packState/unpackState` देखो |

---

## 10. Legal & compliance (भारत में चलाने से पहले)

- ✅ **कोई copyrighted music/photos use नहीं** — सब WebAudio + CSS/canvas से बना है
- ✅ **कोई celebrity content नहीं** — इससे copyright + misinformation का risk होता है
- ✅ **कोई personal data server पर store नहीं** — privacy-friendly
- ⚠️ **SMS add करना हो तो DLT** लागू है (DLT PE ₹5,900 + GST, header ₹590/yr, 10am–9pm promotional window, ₹0.08–0.28/SMS)
- ⚠️ **WhatsApp BSP API** (या bulk WhatsApp) Business API + template approval चाहिए, और Meta की policy में opt-in ज़रूरी है
- ⚠️ AdSense/Adsterra के ToS पढ़कर चलो; "incentivized traffic" (दूसरे को link भेजने पर payment) से account suspend होता है
- 💼 B2B contract में बताओ: "content आपका, design हमारा" + advance payment

---

## 11. Pro version में क्या-क्या नया है (v2)

पहले वाले MVP से अब ये सब जुड़ा है:

**Landing page (index.html)**
- ✅ Sticky top bar + nav anchors (कैसे काम करता है / लिंक बनाओ / सवाल / दुकान के लिए)
- ✅ Hero में **live phone mockup** + "LIVE" badge
- ✅ **"कैसे काम करता है"** 3-step cards + 4 feature strips (मुफ़्त, कोई signup नहीं, 4G तेज़, डेटा सेव नहीं)
- ✅ **Character counter** नाम/मैसेज/"from" के साथ
- ✅ **FAQ section** (7 सवाल, `<details>` based — zero JS) → Google में rich results
- ✅ **B2B panel** — दुकानों के लिए pricing (₹2,999 / ₹6,999 / ₹9,999+) + WhatsApp CTA
- ✅ **Growth-loop explainer** ("ये भी भेजो" कैसे काम करता है)
- ✅ **JSON-LD structured data** (WebSite + CreateAction) → SEO boost
- ✅ **Back-to-top** button, footer में 3-column layout + legal/disclaimer
- ✅ **Accessibility:** aria-labels, `aria-live` toast, keyboard focus rings, `prefers-reduced-motion` support
- ✅ Enter key से सीधे लिंक बन जाता है; `index.html#f=holi&n=Rahul` खोलते ही fields भरे हुए आते हैं
- ✅ **NFC normalization** → same name हमेशा same link

**Recipient page (wish.html)**
- ✅ **Curtain पर tap** = तुरंत खुलता है (+ तभी संगीत चल पाता है, mobile policy के अनुसार)
- ✅ "**यह शुभकामना आपके लिए है 🎁**" ribbon
- ✅ नाम reveal पर **बड़ी आतिशबारी** + screen vignette
- ✅ "👆 कहीं भी टैप करो" hint पहली tap के बाद अपने आप छिप जाता है
- ✅ Tab title में नाम (`राहुल शुभ दीपावली | शुभकामना`)

**SEO / deploy**
- ✅ `noindex` on wish.html (हज़ारों hash-links = duplicate content नहीं)
- ✅ Absolute OG image URL (WhatsApp preview के लिए ज़रूरी)
- ✅ 404 page (themed, working relative links)
- ✅ sitemap.xml, robots.txt, CNAME.example, Pages workflow

---

## 12. Test results (75/75 ✅)

पूरी साइट का automated test suite (`/home/user/tests/fulltest.js`, jsdom-based) — **75 assertions, 0 failures, 0 JS errors**:

| Block | क्या test हुआ |
|---|---|
| **A. Build** | सारी files मौजूद · JS syntax (5 files) · HTML structure balanced (3 pages) · हर asset reference valid · कोई third-party JS lib नहीं · workflow valid · robots/sitemap valid · पेज वज़न < 120KB |
| **B. Landing** | 11 त्योहार render · nav anchors valid · theme/preview-hint/iframe sync · counters · empty-name blocked + toast · link generation (decoded) · WhatsApp href · history save/clear · footer year · back-to-top · hash prefill |
| **C. Recipient** | title/name/from · sheen · scene nodes · share text · "ये भी भेजो" · tab title · typewriter पूरा (emoji सहित) · curtain auto-open + tap-open · tap → hint छिपा · music toggle aria · **XSS safe** (script/onerror inject नहीं होता) · 11 त्योहार error-free |
| **D. 404** | relative links · sparkles script |
| **E. Content/SEO** | OG absolute URL · canonical · JSON-LD valid · FAQ/B2B sections · AdSense+Adsterra slots · noindex · README completeness |

```bash
cd /home/user/tests
npm init -y && npm i jsdom        # एक बार (सिर्फ़ test के लिए, site को कुछ फ़र्क नहीं)
node fulltest.js                  # re-run करो
# दूसरी copy (drag-and-drop वाली) test करनी हो तो:
ROOT_OVERRIDE=/home/user/wish-site-upload node fulltest.js
```

---

## 13. Quick checklist (launch से पहले)

- [ ] `example.com` → अपना domain (sed command)
- [ ] Adsterra/PopAds code paste किया
- [ ] WhatsApp पर खुद 3-4 लिंक test किए (Diwali, Holi, Birthday, Good Morning)
- [ ] मोबाइल पर खोलकर देखा (Chrome + WhatsApp in-app browser)
- [ ] `CNAME` + DNS records (custom domain वालों के लिए)
- [ ] 404 page test किया (`/xyz`)
- [ ] 10-15 लिंक पहले से बना कर रखा (त्योहार से 10 दिन पहले)
- [ ] 20 local businesses से contact किया (B2B pitch)
- [ ] Analytics (optional): Plausible / Cloudflare Web Analytics — free, cookie-less, India traffic दिखेगा

---

## 14. License

MIT — freely use, modify, sell. Music, images, animations सब self-made हैं, तो कोई attribution ज़रूरी नहीं.

Made with ❤️ in Bharat 🇮🇳
