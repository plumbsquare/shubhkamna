# 🚀 START HERE — शुभकामना को live करो

3 में से कोई भी रास्ता चुनो। **सबसे आसान = रास्ता A (drag & drop)**, सबसे "सब कुछ अपने आप" = रास्ता B (एक command).

---

## रास्ता A — Drag & Drop (बस browser, कोई command नहीं) ⭐ सबसे आसान

| Step | क्या करना है |
|---|---|
| **1** | [github.com/new](https://github.com/new) → Repo name: **`shubhkamna`** → "Add a README file" **ON** → **Create repository** |
| **2** | Repo page → **Add file → Upload files** → इस zip की **सारी files/folders** (खोलकर) upload box में drag & drop करो |
| **3** | नीचे scroll → **Commit changes** |
| **4** | **Settings → Pages** → Source: **"Deploy from a branch"** → Branch `main` → Folder `/ (root)` → **Save** |
| **5** | 1–2 मिनट में live → `https://<username>.github.io/shubhkamna/` |

> **`.github` folder नहीं दिख रहा drag & drop में?** कोई बात नहीं — Step 4 "Deploy from a branch" से काम चल जाएगा।
> Auto-deploy workflow चाहिए तो बाद में: zip में मौजूद `pages-workflow.yml` की content को
> **Add file → Create new file** → filename box में लिखो `.github/workflows/pages.yml` → paste → Commit.

---

## रास्ता B — एक Command (सब कुछ अपने आप) 🤖 सबसे "set & forget"

**ज़रूरी:** [Git for Windows](https://git-scm.com/downloads) + [GitHub CLI `gh`](https://cli.github.com)

```bash
# zip extract करो, फिर उस folder में:
./setup.sh                          # repo: shubhkamna
./setup.sh my-wish-site             # दूसरा repo नाम
./setup.sh my-wish-site shubhkamna.in   # + custom domain (CNAME + DNS guide भी देगा)
```
Windows पर: `setup.bat` (same commands)

**ये script अपने आप करेगा:**
1. `_github` → `.github` rename (hidden folder वाली problem fix)
2. `git init` + commit
3. **GitHub repo बनाएगा + push** (`gh` से)
4. **Pages चालू करेगा** (Actions workflow पर)
5. Domain दिया हो तो → `CNAME` file + `CUSTOM_DOMAIN` secret + DNS records की list
6. Final: live URL, repo link, Actions link, Settings link

---

## रास्ता C — सिर्फ़ domain बदलना (बाद में)

Repo → **Settings → Pages → Custom domain** → अपना domain डालो → Save
DNS में (domain provider के panel में):

| Type | Host | Value |
|---|---|---|
| `CNAME` | `www` | `<username>.github.io` |
| `A` | `@` | `185.199.108.153` |
| `A` | `@` | `185.199.109.153` |
| `A` | `@` | `185.199.110.153` |
| `A` | `@` | `185.199.111.153` |

फिर **HTTPS** चालू कर दो (Settings → Pages → Enforce HTTPS) ✅

---

## 🤖 Automation — ये workflow अपने आप करता है

हर push पर ये workflow चलता है (`.github/workflows/pages.yml`):

```
push ──▶ 🧪 TEST (75 assertions — fail हुआ तो deploy रुक जाएगा)
      ──▶ 🧹 PREPARE  (prepare_site.py)
      │      • असली site URL inject (og:url, og:image, canonical, sitemap, robots)
      │      • CUSTOM_DOMAIN secret हो तो CNAME file बनाएगा
      │      • ADSTERRA_SCRIPT secret हो तो ad slot में code डालेगा
      │      • ADSENSE_CLIENT + ADSENSE_SLOT हों तो AdSense block active
      ──▶ 🌐 DEPLOY (GitHub Pages)
```

### ⚙️ Secrets कहाँ डालें (एक बार)
**Repo → Settings → Secrets and variables → Actions → New repository secret**

| Secret | क्या डालें | फ़ायदा |
|---|---|---|
| `CUSTOM_DOMAIN` | `shubhkamna.in` | CNAME अपने आप + सारी URLs उसी domain पर |
| `ADSTERRA_SCRIPT` | Adsterra dashboard का loader code (पूरा `<script>...</script>`) | Ads अपने आप लग जाएँगे, हर push पर |
| `ADSENSE_CLIENT` | `ca-pub-XXXXXXXXXXXXXXXX` | AdSense auto-enable |
| `ADSENSE_SLOT` | ad slot id (numbers) | AdSense auto-enable |
| `SITE_URL` | (optional) अगर किसी और URL पर host करना हो | override |

> Secret बदलते ही अगला push उन्हें inject कर देगा। कोई code छूने की ज़रूरत नहीं।

---

## 🧪 अपने आप test कैसे चलाएँ (optional, locally)

```bash
cd tests
npm install     # एक बार (jsdom)
npm test        # 75 assertions → सब green आने चाहिए
```

---

## ✅ Launch checklist

- [ ] Repo बन गया (`shubhkamna`)
- [ ] Files upload / push हो गए
- [ ] Pages चालू → site live
- [ ] Actions tab में green ✅ दिखा
- [ ] Site खोलकर 3-4 लिंक बनाकर WhatsApp पर test किया
- [ ] `CUSTOM_DOMAIN` secret डाला (या बाद में)
- [ ] `ADSTERRA_SCRIPT` secret डाला → अगला push पर ads आ जाएँगे
- [ ] Phone पर खोलकर देखा (Chrome + WhatsApp in-app browser)
- [ ] 20-30 local businesses को B2B message भेजा (README Section 5 script)

---

**कुछ भी अटक जाए तो:** Actions tab का red ❌ खोलो — error क्या है दिख जाएगा।
ज़्यादातर वजह: repo की branch `main` नहीं (workflow दोनों `main`/`master` handle करता है) या `Pages → Source` सही नहीं है।
