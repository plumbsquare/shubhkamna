#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════
#  शुभकामना — ONE-COMMAND SETUP (macOS / Linux)
#
#  ये script सब कुछ अपने आप कर देगा:
#    1. _github → .github rename (hidden folder वाली problem fix)
#    2. git init + commit
#    3. GitHub repo बनाएगा (gh CLI से) + push
#    4. GitHub Pages चालू करेगा (Actions workflow)
#    5. Custom domain (अगर दिया तो) — CNAME + DNS instructions
#    6. Repo secrets सेट करेगा (CUSTOM_DOMAIN / ADSTERRA_SCRIPT / ADSENSE_*)
#
#  USAGE:
#    ./setup.sh                          # repo: shubhkamna, कोई domain नहीं
#    ./setup.sh my-wish-site             # दूसरा repo नाम
#    ./setup.sh my-wish-site shubhkamna.in   # repo + custom domain
#
#  ज़रूरी: gh CLI installed होना चाहिए →  https://cli.github.com
# ══════════════════════════════════════════════════════════════
set -e

REPO_NAME="${1:-shubhkamna}"
DOMAIN="${2:-}"
VISIBILITY="public"
DIR="$(cd "$(dirname "$0")" && pwd)"

red()   { printf "\033[31m%s\033[0m\n" "$*"; }
green() { printf "\033[32m%s\033[0m\n" "$*"; }
cyan()  { printf "\033[36m%s\033[0m\n" "$*"; }
bold()  { printf "\033[1m%s\033[0m\n" "$*"; }

echo ""
bold "═══════════════════════════════════════════"
bold " 🪔  शुभकामना — GitHub Pages setup"
bold "═══════════════════════════════════════════"
echo " फ़ोल्डर : $DIR"
echo "Repo    : $REPO_NAME"
echo "Domain  : ${DOMAIN:-— (बाद में जोड़ सकते हो)}"
echo ""

# ---------- 0. ज़रूरी चीज़ें जाँचो ----------
command -v git  >/dev/null 2>&1 || { red "❌ git install करो: https://git-scm.com/downloads"; exit 1; }
command -v gh   >/dev/null 2>&1 || { red "❌ GitHub CLI (gh) install करो: https://cli.github.com"; exit 1; }
gh auth status >/dev/null 2>&1 || { red "❌ gh login नहीं है. चल रहा हूँ: gh auth login"; gh auth login; }
command -v python3 >/dev/null 2>&1 || echo "⚠️  python3 नहीं है (सिर्फ़ local prepare के लिए चाहिए, workflow के लिए नहीं)"

# ---------- 1. _github → .github ----------
if [ -d "$DIR/_github" ] && [ ! -d "$DIR/.github" ]; then
  mv "$DIR/_github" "$DIR/.github"
  green "✅ _github → .github rename हो गया"
fi
if [ ! -f "$DIR/.github/workflows/pages.yml" ]; then
  red "❌ .github/workflows/pages.yml नहीं मिला — zip सही extract हुई है कि नहीं देखो"
  exit 1
fi

# ---------- 2. git init + commit ----------
cd "$DIR"
if [ ! -d ".git" ]; then
  git init -q
  green "✅ git init"
fi
git add -A
if git diff --cached --quiet; then
  echo "• कोई नया change नहीं"
else
  git -c user.name="Shubhkamna Setup" -c user.email="setup@shubhkamna.local" \
      commit -q -m "🚀 Shubhkamna v2 — animated greeting links (auto-deploy workflow)"
  green "✅ commit हो गया"
fi

# ---------- 3. repo बनाओ + push ----------
if gh repo view "$REPO_NAME" >/dev/null 2>&1; then
  cyan "ℹ️  Repo '$REPO_NAME' पहले से मौजूद है — उसमें push कर रहा हूँ"
else
  gh repo create "$REPO_NAME" --"$VISIBILITY" --source=. --remote=origin --push
  green "✅ Repo बन गया + push हो गया"
fi
if ! git remote get-url origin >/dev/null 2>&1; then
  git remote add origin "$(gh repo view "$REPO_NAME" --json url -q .url)"
  git push -u origin HEAD
fi

OWNER="$(gh repo view "$REPO_NAME" --json owner -q .owner.login)"
BRANCH="$(git rev-parse --abbrev-ref HEAD)"

# ---------- 4. Pages चालू करो ----------
echo ""
echo "→ Pages enable कर रहा हूँ..."
gh api --method POST "repos/$OWNER/$REPO_NAME/pages" \
   -f source[branch]="$BRANCH" -f source[path]="/" >/dev/null 2>&1 \
  || gh api --method POST "repos/$OWNER/$REPO_NAME/pages" \
       -F build_type=workflow >/dev/null 2>&1 \
  || echo "ℹ️  Pages पहले से enabled है (या बाद में Settings→Pages से कर लो)"

# ---------- 5. Custom domain ----------
if [ -n "$DOMAIN" ]; then
  printf '%s\n' "$DOMAIN" > "$DIR/CNAME"
  git add CNAME
  git -c user.name="Shubhkamna Setup" -c user.email="setup@shubhkamna.local" commit -q -m "🌐 custom domain: $DOMAIN"
  git push -q origin HEAD
  gh secret set CUSTOM_DOMAIN --body "$DOMAIN" --repo "$OWNER/$REPO_NAME"
  green "✅ CNAME + CUSTOM_DOMAIN secret set"
  echo ""
  echo "⚠️  DNS में ये records डालो (domain provider के panel में):"
  echo "     CNAME  www   →  $OWNER.github.io"
  echo "     A      @     →  185.199.108.153"
  echo "     A      @     →  185.199.109.153"
  echo "     A      @     →  185.199.110.153"
  echo "     A      @     →  185.199.111.153"
  echo "     फिर Settings → Pages → Custom domain = $DOMAIN → Save"
fi

# ---------- 6. Ad secrets (अगर पहले से env में हों) ----------
if [ -n "$ADSTERRA_SCRIPT" ]; then
  gh secret set ADSTERRA_SCRIPT --body "$ADSTERRA_SCRIPT" --repo "$OWNER/$REPO_NAME"
  green "✅ ADSTERRA_SCRIPT secret set"
fi
if [ -n "$ADSENSE_CLIENT" ] && [ -n "$ADSENSE_SLOT" ]; then
  gh secret set ADSENSE_CLIENT --body "$ADSENSE_CLIENT" --repo "$OWNER/$REPO_NAME"
  gh secret set ADSENSE_SLOT   --body "$ADSENSE_SLOT"   --repo "$OWNER/$REPO_NAME"
  green "✅ AdSense secrets set"
fi

# ---------- 7. Summary ----------
SITE="https://$OWNER.github.io/$REPO_NAME/"
[ -n "$DOMAIN" ] && SITE="https://$DOMAIN/"

echo ""
bold "═══════════════════════════════════════════"
green " ✅  सब सेट हो गया!"
bold "═══════════════════════════════════════════"
echo ""
echo " 🌐 Site      : $SITE"
echo " 📦 Repo      : https://github.com/$OWNER/$REPO_NAME"
echo " ⚙️  Actions   : https://github.com/$OWNER/$REPO_NAME/actions"
echo " 🔧 Settings  : https://github.com/$OWNER/$REPO_NAME/settings/pages"
echo ""
echo "👉 पहला deploy 1-2 मिनट में हो जाएगा (Actions tab देखो)."
echo "👉 हर बार push करने पर: test चलेगा → URL/ad code inject होगा → deploy होगा."
echo ""
echo " Ads लगाने के लिए (बाद में भी कर सकते हो):"
echo "   Settings → Secrets and variables → Actions → New repository secret"
echo "     • ADSTERRA_SCRIPT  = Adsterra का loader code"
echo "     • ADSENSE_CLIENT   = ca-pub-XXXXXXXXXXXXXXXX"
echo "     • ADSENSE_SLOT     = ad slot id"
echo ""
