#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
prepare_site.py — GitHub Actions में चलता है.

ये काम करता है:
  1. `https://example.com/` को असली site URL से replace करता है
     (index.html, wish.html, robots.txt, sitemap.xml)
  2. CUSTOM_DOMAIN secret से CNAME file बनाता है (custom domain वाला Pages)
  3. ADSTERRA_SCRIPT secret हो तो ad slot में loader code inject करता है
  4. ADSENSE_CLIENT + ADSENSE_SLOT secret हों तो AdSense block active कर देता है

किसी secret नहीं हो तो भी चलता है — बस example.com रह जाएगा (बाद में sed से बदल लेना)।
"""
import os
import re
import sys

ROOT = os.environ.get("GITHUB_WORKSPACE") or os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OWNER = os.environ.get("GITHUB_REPOSITORY_OWNER", "").strip()
REPO = (os.environ.get("GITHUB_REPOSITORY", "") or "").split("/")[-1].strip()
CUSTOM = (os.environ.get("CUSTOM_DOMAIN") or "").strip().strip("/")
SITE_SECRET = (os.environ.get("SITE_URL") or "").strip().rstrip("/")
ADSTERRA = (os.environ.get("ADSTERRA_SCRIPT") or "").strip()
ADSENSE_CLIENT = (os.environ.get("ADSENSE_CLIENT") or "").strip()
ADSENSE_SLOT = (os.environ.get("ADSENSE_SLOT") or "").strip()

FILES = ["index.html", "wish.html", "robots.txt", "sitemap.xml"]


def compute_site_url():
    if SITE_SECRET:
        return SITE_SECRET + "/"
    if CUSTOM:
        return "https://" + CUSTOM + "/"
    if OWNER and REPO:
        if REPO.lower() == (OWNER + ".github.io").lower():
            return "https://%s.github.io/" % OWNER
        return "https://%s.github.io/%s/" % (OWNER, REPO)
    return "https://example.com/"


def read(p):
    with open(p, "r", encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8") as f:
        f.write(s)


def inject_urls(site):
    """Har meta attribute ko apni current site URL se rewrite karta hai.
    Idempotent hai — baar baar chala sakte ho (repo URL -> custom domain switch bhi sahi se handle hota hai)."""
    changed = []

    def set_attr(pattern, value, s):
        return re.sub(pattern, lambda m: m.group(1) + value + m.group(3), s, flags=re.I)

    for name in ["index.html", "wish.html"]:
        p = os.path.join(ROOT, name)
        if not os.path.exists(p):
            continue
        s = read(p)
        n = s
        n = set_attr(r'(<meta[^>]+property="og:url"[^>]+content=")([^"]*)(")', site, n)
        n = set_attr(r'(<meta[^>]+property="og:image"[^>]+content=")([^"]*)(")', site + "assets/img/og.jpg", n)
        n = set_attr(r'(<meta[^>]+property="og:image:secure_url"[^>]+content=")([^"]*)(")', site + "assets/img/og.jpg", n)
        n = set_attr(r'(<meta[^>]+name="twitter:image"[^>]+content=")([^"]*)(")', site + "assets/img/og.jpg", n)
        n = set_attr(r'(<link[^>]+rel="canonical"[^>]+href=")([^"]*)(")', site, n)
        if n != s:
            write(p, n)
            changed.append(name)

    p = os.path.join(ROOT, "robots.txt")
    if os.path.exists(p):
        s = read(p)
        n = re.sub(r'(?im)^(Sitemap:\s*)\S+', lambda m: m.group(1) + site + "sitemap.xml", s)
        if n != s:
            write(p, n)
            changed.append("robots.txt")

    p = os.path.join(ROOT, "sitemap.xml")
    if os.path.exists(p):
        s = read(p)
        n = re.sub(r'(?s)(<loc>)[^<]*(</loc>)', lambda m: m.group(1) + site + m.group(2), s)
        if n != s:
            write(p, n)
            changed.append("sitemap.xml")

    return changed


def inject_cname():
    if not CUSTOM:
        return False
    p = os.path.join(ROOT, "CNAME")
    write(p, CUSTOM + "\n")
    return True


def inject_adsterra():
    if not ADSTERRA:
        return []
    # commented placeholder को असली loader code से बदलो
    pat = re.compile(
        r'<!--\s*(?:<!--\s*)?<script[^>]*profitablereliance[^>]*>\s*</script>\s*(?:-->)?\s*-->',
        re.I,
    )
    touched = []
    for name in ["index.html", "wish.html"]:
        p = os.path.join(ROOT, name)
        if not os.path.exists(p):
            continue
        s = read(p)
        n = pat.sub(ADSTERRA, s)
        if n == s:  # placeholder नहीं मिला तो ad slot के आगे लगा दो
            n = s.replace("<!-- ad slot (optional) -->", ADSTERRA)
        if n != s:
            write(p, n)
            touched.append(name)
    return touched


def inject_adsense():
    if not (ADSENSE_CLIENT and ADSENSE_SLOT):
        return []
    pat = re.compile(r"<!--\s*(<ins class=\"adsbygoogle\".*?</script>)\s*-->", re.S)
    touched = []
    for name in ["index.html", "wish.html"]:
        p = os.path.join(ROOT, name)
        if not os.path.exists(p):
            continue
        s = read(p)
        def fix(m):
            blk = m.group(1)
            blk = blk.replace("ca-pub-XXXXXXXXXXXXXXXX", ADSENSE_CLIENT)
            blk = blk.replace('data-ad-slot="XXXXXXXXXX"', 'data-ad-slot="%s"' % ADSENSE_SLOT)
            return blk
        n = pat.sub(fix, s)
        if n != s:
            write(p, n)
            touched.append(name)
    return touched


def main():
    site = compute_site_url()
    changed = inject_urls(site)
    cname = inject_cname()
    ads = inject_adsterra()
    adsense = inject_adsense()

    print("→ Site URL      :", site)
    print("→ URL replaced  :", ", ".join(changed) if changed else "कुछ नहीं")
    print("→ CNAME written :", "हाँ (%s)" % CUSTOM if cname else "नहीं (CUSTOM_DOMAIN secret नहीं है)")
    print("→ Adsterra inject:", ", ".join(ads) if ads else "नहीं (ADSTERRA_SCRIPT secret नहीं है)")
    print("→ AdSense inject :", ", ".join(adsense) if adsense else "नहीं (client+slot secret नहीं हैं)")
    print("→ तैयार है — अब deploy करो ✅")


if __name__ == "__main__":
    sys.exit(main())
